# Sumber audio ElevenLabs

Semua audio di video final dibuat dengan ElevenLabs (paket Free) lewat koneksi MCP di sesi Claude cloud.

## Voice-over

- Suara: "Eric - Smooth, Trustworthy" (premade, voice_id `cjVigY5qzO86Huf0OWal`), model Eleven Multilingual v2.
- Tiap baris dibuat 2 take. Take yang dipakai ada di `public/audio/vo/import/vo1.mp3` ... `vo8.mp3`
  (dipilih yang temponya paling dekat dengan rata-rata; vo8 dipilih karena ada jeda sebelum "Try").
- `vo-alternates/vo1.mp3` ... `vo8.mp3`: take kedua (cadangan).

Ganti satu baris dengan take cadangan, misalnya vo5:

    cp audio-sources/elevenlabs/vo-alternates/vo5.mp3 public/audio/vo/import/vo5.mp3
    npm run vo:import -- --only vo5
    npm run render:final

## Efek suara

- ElevenLabs Sound Effects v3, prompt dan durasi dari `scripts/audio/sfx-categories.json`.
- `sfx-raw/`: file asli dari ElevenLabs (click punya dua versi; yang dipakai `click_a`).
- Yang dipakai di video: `public/audio/sfx/library/<kategori>.wav`. Versi ini sudah dipotong heningnya di awal
  supaya bunyi pas di frame, diberi fade sangat pendek, dan puncaknya disamakan (-3 dBFS; chime dan typing-bed -6).

## Mix yang disetujui

`public/audio/mix.json`: `vo.gain` 0.6, `vo.fade_in_frames` 0, `sfx.master_gain` 1.0, `sfx.under_vo_gain` 0.6.
Semua gain harus 1 atau kurang (preview di Remotion Studio error kalau lebih dari 1).

## Lisensi

Dibuat dengan paket Free ElevenLabs: tidak boleh dipakai komersial, dan judul postingan wajib memuat
"elevenlabs.io" atau "11.ai". Dengan paket berbayar, buat ulang suara dan efeknya supaya berlisensi komersial
(lihat CLAUDE.md, bagian Current state).
