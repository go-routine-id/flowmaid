# Audio scripts (voice-over, sound effects, music, loudness)

Plain Node ESM (Node 18+), no extra npm dependencies, works on macOS / Windows / Linux.
ffmpeg/ffprobe: Remotion's bundled binaries from `node_modules` (same as `npx remotion ffmpeg`), else the
system ffmpeg on PATH, else `FLOWMAID_FFMPEG` / `FLOWMAID_FFPROBE`. ElevenLabs: Node `fetch`, settings in `.env`
(see `.env.example`). The API key is never printed.

## Pipeline

```
voiceover/lines.json ──► npm run vo:tts ─────┐   (ElevenLabs API, cached per line)
                         npm run vo:import ──┤   (files from the ElevenLabs web app in public/audio/vo/import/)
                                             ▼
                          public/audio/vo/manifest.json  (+ vo1..vo8 audio, word timings)
src/flowmaid/cues.ts ──► npm run sfx:plan ──► public/audio/sfx/plan.json ──► npm run sfx:gen (optional)
                                                                             public/audio/sfx/library/<category>.*
public/audio/music/bed.* (optional), public/audio/mix.json (gains, offsets, gaps, loudness)
                                             ▼
                          npm run vo:fit ──► src/flowmaid/audio/audio.generated.ts (VO_CLIPS, SFX_CLIPS, MUSIC,
                                             CAPTION_OVERRIDES) + out/audio-fit.json + out/cues.*, out/captions.srt
                                             ▼
                          npm run render:audio ──► out/flowmaid-promo-audio.raw.mov
                          npm run audio:loudnorm ─► out/flowmaid-promo-audio.mp4  (-16 LUFS, -1.5 dBTP, AAC 48 kHz)
```
`npm run render:final` = vo:fit + render:audio + audio:loudnorm. `npm run vo:reset` = silent film again.

## Commands

| npm script | file | what it does |
|---|---|---|
| `vo:voices` | `elevenlabs/voices.mjs` | list voices (`--type default` = premade, `--search`, `--json`) |
| `vo:tts` | `elevenlabs/tts.mjs` | TTS with timestamps per line; `--only vo3,vo5`, `--dry-run`, `--force`, `--seed N`, `--stitch`, `--skip-voice-check`, `--ignore-credits` |
| `vo:import` | `audio/import-vo.mjs` | per-line files or one `full.mp3`; `--align` (forced alignment, cached; never called with `--dry-run`), `--min-silence`, `--noise`, `--splits`, `--only`, `--mode`, `--dry-run` |
| `vo:fit` | `audio/fit.mjs` | place VO/SFX/music, move captions; `--dry-run`, `--allow-missing`, `--json`, `--no-cues` |
| `vo:reset` | `audio/fit.mjs --reset` | empty generated file (silent film, lead/tail captions) |
| `sfx:plan` | `audio/sfx-plan.mjs` | cue sheet -> plan.json via `audio/sfx-categories.json`; keeps hand edits; `--fresh` |
| `sfx:gen` | `elevenlabs/sfx.mjs` | sound-generation per category without a file; `--only`, `--all`, `--dry-run`, `--force` |
| `audio:loudnorm` | `audio/loudnorm.mjs` | two-pass EBU R128; `--in`, `--out`, `--target`, `--tp`, `--lra` |
| `mock:elevenlabs` | `dev/mock-elevenlabs.mjs` | local fake API for tests (`--port`, `--fail 401\|402\|403\|perm\|quota\|429:N\|500:N`, `--fail-path`, `--no-alignment`, `--tier`, `--credits`) |
| `mock:on` / `mock:off` / `mock:status` | `dev/mock-session.mjs` | save the project state + write `.env.local` for the mock / restore it exactly and delete what the test made |

## Rules fit.mjs applies

- Speech of line N starts at its caption window start (`lead` in `VO_LINES`, `src/flowmaid/timeline.ts`) plus
  `vo.offset_frames` + `vo.per_line.<id>.offset_frames` (mix.json). Speech may run over a cut.
- ERROR (nothing written, exit 1) if a line ends less than `fit.min_gap_frames` (6) before the next one starts, or
  after `TOTAL - fit.end_margin_frames` (1074). The message gives a table and concrete fixes: per-line offsets
  (free), `override.speed` in lines.json + `vo:tts --only` (TTS) or `playback_rate` (imports), shorter wording,
  or the timeline lead. It also prints one combined offset set that fits. `fit.auto_shift` lets fit move lines
  itself by up to N frames (default 0 = off).
- Captions: `from` = speech start, `to` = speech end + 10 f (clamped to the next line and to the caption's own
  lead/tail window end, so a caption never lingers over a cut its speech does not cross; the last caption ends by its
  lead/tail window end, frame 1078, so the final frames show the clean end lockup).
  vo8 -> vo8a / vo8b split at the word "Try" (word timings), else by characters.
- Caption TEXT is drawn from `VO_LINES` in timeline.ts (`text`; vo8: `parts[].text`). fit warns when lines.json
  differs (`text`; vo8: `captions[].text`) and names both fields.
- SFX: enabled plan entries with a library file; gain x `sfx.master_gain`, x `sfx.under_vo_gain` under speech.
- Music: `public/audio/music/bed.*`, ducked to `music.duck_under_vo_to` under speech.

## Testing without a key

Follow Playbook G in `CLAUDE.md`: `npm run mock:on` (saves the project state, writes `.env.local` for the mock;
works the same in cmd, PowerShell and bash), `npm run mock:elevenlabs` in the background, run the scripts, stop the
mock, `npm run mock:off` (puts every file back as it was and deletes what the test made). The cache key includes the
API host, so mock audio is never reused for real requests.

## Files

- `.cache/elevenlabs/` API response cache: `tts/`, `sfx/`, `forced-alignment/` (outside public/, safe to delete;
  refilling costs credits). `.cache/mock-session/` exists only while a mock session is on.
- `public/audio/vo/manifest.json` per line: `file` (path under public/), `duration_s`, `speech_start_s`,
  `speech_end_s`, `audible_start_s/end_s`, `words[{word,start_s,end_s}]`, `request_id`, `hash`, `source`.
- `lib/` shared helpers: `env.mjs` (.env parser), `ff.mjs` (ffmpeg resolver, silencedetect), `timeline.mjs`
  (bundles `src/flowmaid/cues.ts` with esbuild), `esbuild.mjs` (finds Remotion's esbuild), `elevenlabs.mjs` (fetch
  client, retries, error advice), `vo.mjs`, `mix.mjs`, `paths.mjs`, `util.mjs`.

ElevenLabs facts used (endpoints, limits, plan rules) and what is unverified are noted at the top of each script.
