import { Config } from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
Config.setChromiumOpenGlRenderer('angle');
// Render tabs in parallel. 4 by default; a busy or small machine can time out on the font loader
// ("flowmaid fonts" delayRender): set FLOWMAID_CONCURRENCY=2 (or 1) in the shell and render again.
const concurrency = Number.parseInt(process.env.FLOWMAID_CONCURRENCY ?? '', 10);
Config.setConcurrency(Number.isFinite(concurrency) && concurrency > 0 ? concurrency : 4);
// Async loaders (fonts, SVG markup) can wait > 30 s for the static server while 4 tabs extract
// video frames; the default 30 s delayRender timeout failed one integration render.
Config.setDelayRenderTimeoutInMilliseconds(120000);

// Browser: by default Remotion finds or downloads its own Chrome Headless Shell (needs network
// access to Remotion's download host once). On a machine where that is blocked, point
// FLOWMAID_BROWSER_EXECUTABLE at a local Chrome / Chromium / chrome-headless-shell binary.
// Applies to every CLI command (render, still, studio). A --browser-executable flag still wins.
const browser = process.env.FLOWMAID_BROWSER_EXECUTABLE;
if (browser && browser.trim() !== '') {
  Config.setBrowserExecutable(browser.trim());
}
