# Mulai di sini

Paket ini berisi proyek video promo LinkedIn flowmaid (36 detik, 1080x1350) yang siap diberi suara
ElevenLabs. Gambar video sudah final. Yang ditambahkan: voice-over, efek suara (opsional), musik (opsional),
dan caption yang mengikuti suara.

## Isi paket

- `deliverables/silent/`: video bisu yang sudah jadi, cover, cue sheet, dan caption (`.srt`).
- `CLAUDE.md`: petunjuk untuk Claude Code di komputermu (bahasa Inggris, untuk AI).
- `voiceover/SCRIPT.md`: naskah 8 baris, teks untuk ditempel ke web app ElevenLabs, cara pengucapan.
- `src/`, `public/`, `scripts/`: proyek Remotion dan skrip audio. Tidak perlu dibuka.

## 5 langkah

1. Pasang Node.js versi 18 atau lebih baru, dan Claude Code.
2. Ekstrak zip ini, lalu buka terminal di folder `flowmaid-linkedin-video`.
3. Jalankan `npm ci` (sekali saja; mengunduh Remotion, kira-kira 320 MB). Render pertama juga mengunduh
   Chrome khusus milik Remotion.
4. Salin `.env.example` menjadi `.env`, lalu isi baris `ELEVENLABS_API_KEY=` dengan API key ElevenLabs-mu
   (dibuat di web app ElevenLabs, bagian API keys). Edit file ini sendiri di editor. Jangan tempel key di chat.
   Tidak punya API key? Lewati langkah ini; suara bisa dibuat di web app ElevenLabs lalu diimpor.
5. Jalankan `claude` di folder ini, lalu ketik kalimat di bawah. Kalau Claude bertanya soal server MCP
   "elevenlabs", boleh pilih tolak; tidak wajib (skrip di paket ini tidak memakainya).

## Kalimat untuk Claude

> Baca CLAUDE.md lalu buatkan voice-over ElevenLabs untuk video ini.

Claude akan meminta izin sebelum memakai kredit, membiarkanmu memilih suara, lalu membuat
`out/flowmaid-promo-audio.mp4`. Mau tambah efek suara? Bilang: "Tambahkan efek suara juga."

## Lisensi (penting sebelum posting)

- Paket Free ElevenLabs: hasil suara TIDAK boleh dipakai komersial, dan judul postingan wajib memuat
  "elevenlabs.io" atau "11.ai". Paket berbayar (paling murah: Starter) sudah termasuk lisensi komersial.
  Untuk promosi proyek di LinkedIn, paket berbayar paling aman. Cek ulang syaratnya di situs ElevenLabs.
- Efek suara dan musik milikmu sendiri: pastikan lisensinya boleh untuk video promosi.
- Remotion gratis untuk perorangan dan perusahaan sampai 3 karyawan. Rincian lain: `THIRD_PARTY.md`.
