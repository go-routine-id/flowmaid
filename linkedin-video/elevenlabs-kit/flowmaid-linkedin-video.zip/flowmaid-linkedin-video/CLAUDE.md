# flowmaid LinkedIn video: add an ElevenLabs voice-over

This folder is a Remotion 4.0.484 / React 19 project. Composition `FlowmaidPromo` is a finished 36 s promo
(1080x1350, 30 fps, 1080 frames) for flowmaid, an open-source Rust crate that renders Mermaid diagrams to SVG.
The picture is approved and final. Your job: add a voice-over (ElevenLabs API or web-app files), optional sound
effects and music, let the burned-in captions follow the real speech, and render a final MP4 with audio.
Everything is already built and tested against a mock API; you mostly run npm scripts and edit JSON.

## Talking to the owner

- The owner writes Indonesian. Reply in short, plain Indonesian. Keep code, file names and commands as they are.
- Ask before anything that spends ElevenLabs credits: show the `--dry-run` estimate first, then wait for "ya".
- Ask before changing any spoken or on-screen wording. Choosing a voice is the owner's call: play candidates, let them pick.
- Report at the end: output file path, voice name, credits used (from the script output), and the licence reminder.

## Hard rules

1. Do not change the picture or the design: no edits to `SHOTS` durations, `src/flowmaid/shots/`, `tokens.ts`,
   `Chrome.tsx`, `Main.tsx`, `lib/`, `Root.tsx`. Captions may move (that is the point); visuals may not.
2. Allowed edits: `voiceover/lines.json`, `public/audio/mix.json`, `public/audio/sfx/plan.json`, audio files in
   `public/audio/vo/`, `public/audio/sfx/library/`, `public/audio/music/`, and, only when a playbook says so,
   `text` / `lead` / `tail` in `VO_LINES` (`src/flowmaid/timeline.ts`). `src/flowmaid/audio/audio.generated.ts` is
   written ONLY by `npm run vo:fit` / `npm run vo:reset`; never hand-edit it.
3. Claims: say and show only what `BRIEF.md` ("Claims you may make") allows: pure Rust, Mermaid text in / clean SVG out,
   zero dependencies, 12 diagram types, about 113x faster than mermaid.js (geometric mean over 25 sample diagrams),
   runs in the browser as WebAssembly with live re-routing on drag, flowcli (`--watch` redraws on save), dbx lays out
   its ERD with flowmaid, GPL-3.0-or-later, `cargo add flowmaid`, the two links on the end card. Nothing else.
4. No personal branding, no personal data, no emoji, no hype in the script.
5. Secrets: the API key lives only in `.env` (or `.env.local`). Never print, `cat`, grep-with-output, log or commit
   these files, never put a key in code, chat, `.mcp.json` or a command line. Ask the owner to paste the key into
   `.env` with their editor. The scripts only ever say whether the key is set.
6. Keep the silent master: `deliverables/silent/` is the approved silent film + cover + cue sheet. Never overwrite it.
   `npm run vo:reset` brings the project back to exactly that state (empty generated file, lead/tail captions).
7. Deterministic Remotion code only (no `Date.now`, `Math.random`, argless `new Date`). No new npm dependencies.
8. Remotion's CLI also loads `.env` / `.env.local` into the preview/render bundle (local only). Never read
   `process.env.ELEVENLABS_*` from `src/`, and never publish a Remotion bundle while a key is in `.env`.
9. Ignore `npm audit` output ("N vulnerabilities ... npm audit fix --force"). Never run `npm audit fix`, `npm update`
   or `npm install <pkg>`, and never change versions in `package.json` / `package-lock.json`: the pinned Remotion
   and React versions are what this film was approved with. Use npm (`npm ci`), not pnpm or yarn.

## Quick start

1. `npm ci` (Node 18+). Installs Remotion with its own ffmpeg/ffprobe binaries. It ends with an `npm audit`
   vulnerability count: ignore it (hard rule 9).
2. `npm run typecheck` must pass.
3. The first `still`/`render`/`dev` downloads Remotion's own Chrome Headless Shell (once, needs internet).
   Only if that fails: see Troubleshooting (FLOWMAID_BROWSER_EXECUTABLE).
4. Smoke test: `npm run still:flowmaid -- out/check-f0330.png --frame=330` and look at the PNG.
5. `npm run dev` opens Remotion Studio; pick `FlowmaidPromo` (ignore `AiflPromo`, it is the old template, like
   `npm run render:template` / `still:template`, `TEMPLATE.md`, `THEMES.md`, `src/aifl/`, `src/themes/`).

## File map

| Path | What it is |
|---|---|
| `BRIEF.md`, `DESIGN.md` | Hard constraints and the design spec (read-only for you). `DESIGN.md` section 15 = audio layer. |
| `voiceover/lines.json` | THE script: `text` (caption), `tts_text` (spoken, abbreviations spelled out), per-line `override` (speed, voice_settings, seed); vo8's two captions in `captions[].text`. |
| `voiceover/SCRIPT.md` | Human copy of the script with current caption windows, web-app paste text, pronunciation. |
| `public/audio/mix.json` | Gains, per-line offsets, gaps, caption hold, `fit.auto_shift`, SFX/music gains, loudness target. |
| `public/audio/vo/` | Generated VO (`vo1..vo8` + `manifest.json` + alignments). `import/` = files from the web app. |
| `public/audio/sfx/plan.json`, `sfx/library/` | One SFX entry per visual cue (78, 58 enabled); one sound file per category (13). |
| `public/audio/music/` | Optional `bed.mp3` / `bed.wav`. |
| `src/flowmaid/audio/` | `types.ts` (contract), `audio.generated.ts` (output of vo:fit), `AudioLayer.tsx`, `mix.ts`. |
| `src/flowmaid/timeline.ts` | `SHOTS` (do not touch), `VO_LINES` (caption text, lead/tail), `CAPTIONS` (overrides win). |
| `scripts/` | Node ESM pipeline; `scripts/README.md` lists every flag. |
| `docs/elevenlabs-api-notes.md` | Verified ElevenLabs facts with sources and the UNVERIFIED list. Read it before answering API questions. |
| `deliverables/silent/` | Approved silent master: `flowmaid-promo.mp4`, `cover.png`, `cues.csv`, `cues.md`, `captions.srt`. |
| `out/` | Everything rendered or exported (git-ignored). |

## How the audio pipeline fits together

`vo:tts` or `vo:import` -> `public/audio/vo/manifest.json` (speech start/end, word timings) -> `vo:fit` places each
line at its caption window start + offsets, adds SFX (plan.json, only categories with a library file) and the music
bed, checks gaps, and writes `audio.generated.ts` (`VO_CLIPS`, `SFX_CLIPS`, `MUSIC`, `CAPTION_OVERRIDES`) plus
`out/audio-fit.json`, `out/cues.*`, `out/captions.srt`. Captions then run from speech start to speech end + 10 f.
`render:audio` -> `out/flowmaid-promo-audio.raw.mov` (h264 + PCM). `audio:loudnorm` -> `out/flowmaid-promo-audio.mp4`
(video copied, AAC 48 kHz, -16 LUFS, -1.5 dBTP). `render:final` = `vo:fit` + `render:audio` + `audio:loudnorm`.
Do not convert the `.raw.mov` to AAC any other way: a Remotion AAC intermediate plays 1.3 frames late.
Gains are linear; `music.duck_under_vo_to` is an ABSOLUTE gain (e.g. 0.08), not a multiplier.

## Playbook A: voice-over through the API

1. Copy `.env.example` to `.env`. Ask the owner to paste `ELEVENLABS_API_KEY=...` into `.env` themselves. Suggest a
   restricted key: permissions Text to Speech + Voices (read); optional Sound Effects, Forced Alignment, User (read);
   a small credit quota.
2. `npm run vo:voices -- --type default` (free). Premade voices are the ones the Free plan can use via the API.
   Never use a voice id from memory. Default when `ELEVENLABS_VOICE_ID` is empty: George (premade).
3. Audition on vo1 only (47 characters, about 47 credits per voice): set `ELEVENLABS_VOICE_ID` in `.env`, run
   `npm run vo:tts -- --only vo1 --dry-run`, get OK, then `npm run vo:tts -- --only vo1`. The owner listens to
   `public/audio/vo/vo1.mp3`. Repeat per candidate. Cached per voice, so going back to a voice is free.
4. Voice chosen: `npm run vo:tts -- --dry-run` (about 413 characters = about 413 credits on multilingual v2), get OK,
   then `npm run vo:tts`. Only changed lines are billed on later runs. If the credit preflight stops a paid plan
   that bills usage past its allotment, `-- --ignore-credits` goes on (ask the owner first: extra charges).
5. `npm run vo:fit`. If it stops with CLASH / TOO LONG, go to Playbook E. Nothing is written on error.
6. `npm run dev` -> `FlowmaidPromo`: play with sound, check each caption appears with its words.
   Spot stills: `npm run still:flowmaid -- out/check-f0120.png --frame=120`.
7. `npm run render:final` -> `out/flowmaid-promo-audio.mp4`. Confirm the loudness line it prints.
8. Give the owner `out/flowmaid-promo-audio.mp4`, `out/captions.srt` (upload as LinkedIn captions) and
   `deliverables/silent/cover.png` (custom thumbnail; the cover is unchanged).

## Playbook B: voice-over made in the ElevenLabs web app (no API key)

1. The owner generates audio from `voiceover/SCRIPT.md` (model Eleven Multilingual v2): one file per line
   (`vo1.mp3` ... `vo8.mp3`, mp3/wav/m4a) or one take `full.mp3`, saved in `public/audio/vo/import/`.
2. `npm run vo:import -- --dry-run`, check the cuts, then `npm run vo:import` (writes 48 kHz WAV + manifest).
   Full take cut wrong: `--min-silence 0.25`, or `--splits 3.4,6.1,...` (seconds), or `--align` (needs a key;
   billed like speech-to-text) to cut between words. `--align --dry-run` sends nothing: it says what the real run
   would bill (seconds of audio) and shows the pause cuts; get OK before the real `--align` run. Alignment results
   are cached by audio + text, so re-running costs nothing. If alignment fails, the import goes on without it.
3. `npm run vo:fit`, then steps 6-8 of Playbook A. Speed fixes for imports: `playback_rate` (0.9-1.15) in
   `mix.json` `vo.per_line.<id>`, or the owner re-records the line.

## Playbook C: sound effects

- `public/audio/sfx/plan.json` has one entry per visual cue: edit `enabled`, `gain`, `category`, `offset_frames`
  (+ = later), `duration_frames`, `file`. `npm run sfx:plan` regenerates and keeps hand edits; `--fresh` resets.
- Own files: put `<category>.wav|mp3` in `public/audio/sfx/library/` (names: pop, click, key, typing-bed, tick, thud,
  whoosh, swish, chime, riser, flash, shutter, drag-bed). The owner must confirm the licence allows promo use.
  Never use the template's `public/audio/*.mp3` (licences unverified, see THIRD_PARTY.md).
- ElevenLabs: `npm run sfx:gen -- --dry-run` (estimate), OK, then `npm run sfx:gen`. It makes only missing
  categories used by enabled entries and never overwrites the owner's files. `--only pop,whoosh`, `--all`, `--force`.
- Then `npm run vo:fit` (add `--allow-missing` if there is no VO yet). Levels: `mix.json` `sfx.master_gain`,
  `sfx.under_vo_gain` (applied while someone speaks). Keep SFX quiet; the voice leads.

## Playbook D: music bed

- The owner supplies `public/audio/music/bed.mp3` or `bed.wav`, at least 36 s (no looping), licensed for promo use.
- `mix.json` `music`: `gain` 0.22, `duck_under_vo_to` 0.08 (absolute), fades 15 / 45 f, `enabled: false` to drop it.
- `npm run vo:fit`, preview, `npm run render:final`. (ElevenLabs Music API access is for paid plans only, and Free
  music has no commercial rights; no script here generates music.)

## Playbook E: a line does not fit

`vo:fit` prints a table, the exact fix per clash and one combined offset set. Budget per line with no offsets:
vo1 3.00 s, vo2 4.40, vo3 3.63, vo4 3.47, vo5 5.13, vo6 4.67, vo7 5.13, vo8 4.83 (6 f gap; last line ends by f 1074).
Tightest: vo1, vo8, vo6, vo4. Fix in this order:
1. Offsets (free): set `vo.per_line.<id>.offset_frames` in `mix.json` to the printed values. Speech may cross a cut,
   but keep a line inside its own shot where possible (a caption keeps its shot's colours).
2. Let fit solve it: `mix.json` `fit.auto_shift` = `{ "max_early_frames": 10, "max_late_frames": 15 }`. Re-run.
3. Speed, API voice: `lines.json` line `override: { "speed": 1.1 }` (0.7-1.2; not sent on eleven_v4, which has no
   speed), then `npm run vo:tts -- --only vo1` (bills that line only). Imports: `playback_rate` (see Playbook B).
4. Wording (ask the owner; stay inside the allowed claims). The film draws captions from `VO_LINES` in `timeline.ts`,
   so change both files:
   - vo1-vo7: `text` + `tts_text` in `lines.json`, and `text` of that line in `VO_LINES`.
   - vo8 (two captions): `text`, `tts_text` and `captions[0].text` / `captions[1].text` in `lines.json` (keep
     `starts_at_word` = the first word of the second caption), and `parts[0].text` / `parts[1].text` of line 8 in
     `VO_LINES` (its `text` is not drawn).
   `vo:fit` warns when they differ and names both fields. Then `npm run vo:tts -- --only <id>`.
5. Window: `lead` (frames after the shot start) of that line in `VO_LINES`. Never change `SHOTS`.

## Playbook F: cue sheet and captions

- `npm run vo:fit` already refreshes `out/cues.csv`, `out/cues.md`, `out/captions.srt` from the fitted windows.
- `npm run cues:flowmaid` re-exports at any time. After `npm run vo:reset` the three files are byte-identical to
  `deliverables/silent/`.

## Playbook G: test without credits (local mock)

1. `npm run mock:on`: saves the project state to `.cache/mock-session/` and writes `.env.local` that points every
   ElevenLabs script at the mock (`ELEVENLABS_BASE_URL=http://127.0.0.1:8787`, `ELEVENLABS_API_KEY=mock-key`;
   `.env.local` wins over `.env`, works on every OS). It refuses if `.env.local` already exists or if
   `ELEVENLABS_*` is set in the shell.
2. Start `npm run mock:elevenlabs` as a background process (real tone audio, about 14 chars/s, so fit results and
   speed fixes on it say nothing about the real voice). Run any playbook. Errors: restart the mock with
   `-- --fail 401|402|403|perm|quota|429:2|500:3` (`perm` = a key without a permission), `-- --no-alignment`
   (a model without word timings) or `-- --tier free --credits 100` (the credit preflight stop).
3. Clean up: stop the mock process, then `npm run mock:off`. It restores `lines.json`, `mix.json`, `plan.json`,
   `timeline.ts`, `audio.generated.ts`, the out/ cue files and everything in `public/audio/vo/`, `sfx/library/`,
   `music/`; it deletes what the test added there, new files in `out/` and `.cache/elevenlabs/`, and the
   `.env.local` it wrote. Offsets or speeds tuned on the mock must not reach the real run: always end with
   `mock:off` (`npm run mock:status` tells whether a session is open). Mock audio is never reused for real
   requests anyway (the API host is part of every cache key).

## ElevenLabs facts that matter here (sources in docs/elevenlabs-api-notes.md)

- Auth header `xi-api-key`, env var `ELEVENLABS_API_KEY`, base `https://api.elevenlabs.io`. Requests go one at a time.
- Model: default `eleven_multilingual_v2` (1 credit/char; supports speed, `<break>`, stitching, `/with-timestamps`).
  `eleven_flash_v2_5` costs 0.5 credit/char. `eleven_v3` has speed/style but no `<break>`; `eleven_v4` has no
  speed/style/SSML. On both, word timings in `/with-timestamps` are undocumented: when a response has none, the
  script calls forced alignment per line (extra cost; the dry run says so). Set `ELEVENLABS_MODEL_ID` in `.env`.
- Output `mp3_44100_128` works on every plan; `mp3_44100_192` needs Creator+, PCM/WAV 44.1 kHz needs Pro+.
- `speed` is clamped to 0.7-1.2. `seed` gives best-effort determinism only; the cache is what keeps re-runs free.
- Break tags: `<break time="1.5s" />`, up to 3 s, on every model except `eleven_v3` / `eleven_v4`. The API pipeline
  needs none (one request per line, pauses come from placement). Use them only for a web-app full take.
- Free plan: 10,000 credits/month, API access with premade voices only (Voice Library voice -> 402
  `paid_plan_required`), NO commercial licence, attribution required: put "elevenlabs.io" or "11.ai" in the post
  title. Paid plans include a commercial licence; Starter is the cheapest (price from third-party sources only).
  A LinkedIn post promoting a project is safest on a paid plan. Tell the owner this before publishing.
- Sound effects: every category here has a fixed duration, billed per second (sources conflict: budget 20-40
  credits/s); the `sfx:gen` dry run prints the estimate (about 210-430 credits for the categories the plan uses).
  Free-plan API access is unverified (402/403 -> use own files).
- Errors (live API, which differs from the docs): 401 `invalid_api_key` / `missing_api_key` -> owner fixes the key in
  `.env`; 401 `missing_permissions` ("missing the permission voices_read") -> add that permission to the SAME key in
  the web app (Developers -> API keys), no new key needed; 401 `insufficient_credits` / `quota_exceeded` -> stop, no
  retry; 402 `paid_plan_required` -> premade voice or paid plan; 403 -> IP allowlist; 429 / 5xx -> retried with
  backoff. The scripts print this advice themselves.

## ElevenLabs MCP server (optional)

`.mcp.json` registers the official hosted server `https://api.elevenlabs.io/v1/mcp`. It signs in with OAuth (run
`/mcp` in Claude Code and finish the browser sign-in); no API key goes into any file. Use it only to browse or
audition voices interactively. Its generations spend credits like the web app and land in the ElevenLabs workspace,
not in this folder, so they are not reproducible. The npm scripts remain the path for the film. Claude Code asks
for approval before using a project MCP server; declining it changes nothing here.

## Troubleshooting

- Chrome download fails: run `npx remotion browser ensure`. If Remotion's download hosts are blocked, set
  `FLOWMAID_BROWSER_EXECUTABLE` in the shell to a local chrome-headless-shell / Chrome / Chromium binary
  (`remotion.config.ts` reads it for every command), or append `-- --browser-executable=<path>` to the npm script.
  bash/zsh: `export FLOWMAID_BROWSER_EXECUTABLE=/path/to/chrome`; PowerShell: `$env:FLOWMAID_BROWSER_EXECUTABLE="C:\path\chrome.exe"`.
  This variable is not read from `.env`.
- ffmpeg/ffprobe missing: the scripts use Remotion's bundled binaries (`npx remotion ffmpeg -version` to check),
  then a system ffmpeg on PATH, then `FLOWMAID_FFMPEG` / `FLOWMAID_FFPROBE` (shell variables). If the bundled ones
  are missing, `npm ci` was run with optional deps omitted: re-run plain `npm ci`.
- 401 / 403 / 402 / quota / 429: see the facts above (a 401 can mean a missing permission or no credits, not only a
  bad key: read the advice lines). Never "fix" an auth error by printing the key.
- Captions do not move: `vo:fit` failed (it writes nothing on error) or was not run. Check that `CAPTION_OVERRIDES`
  in `src/flowmaid/audio/audio.generated.ts` is filled and reload Studio. Caption TEXT comes from `VO_LINES`.
- No audio in the video: you rendered `render:silent` (it is `--muted`), `audio.generated.ts` is empty, or you are
  looking at the `.raw.mov`. Final file: `out/flowmaid-promo-audio.mp4`; check with
  `npx remotion ffprobe out/flowmaid-promo-audio.mp4` (expect h264 + aac, 1080 frames).
- Clipping or harsh mix: lower `vo.gain`, `sfx.master_gain` or `music.gain`; loudnorm sets the final level and peak.
- Windows: npm scripts work in cmd and PowerShell. Pass flags after `--` (`npm run vo:tts -- --only vo1`).
  Prefer `.env` / `.env.local` over shell variables for ELEVENLABS_* settings.

## Done checklist

- `npm run typecheck` passes; `npm run vo:fit` ends without CLASH / TOO LONG.
- `out/flowmaid-promo-audio.mp4` exists, h264 + AAC 48 kHz, 1080 frames, loudness about -16 LUFS.
- Listened in Studio: every line audible, no line cut off, captions match speech, music under the voice.
- No key in any file except `.env` / `.env.local`; `npm run mock:status` says no mock session is active;
  `deliverables/silent/` untouched.
- Final message to the owner in Indonesian, including the Free-plan licence/attribution reminder.
