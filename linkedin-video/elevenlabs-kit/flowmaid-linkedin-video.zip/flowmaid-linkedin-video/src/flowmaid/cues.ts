// Cue sheet aggregator: maps every shot's LOCAL cues (shots/<Name>.cues.ts) through SHOTS
// and adds the generated transition cues. Exported as out/cues.csv + out/cues.md by
// scripts/export-cues.mjs (`node scripts/export-cues.mjs`). Data only — no React imports.
import {
  CAPTIONS, CAPTIONS_LEAD_TAIL, SHOTS, TRANSITION_CUES, cue, fmtTime, type Caption, type Cue, type LocalCue, type ShotId,
} from './timeline';
import { CUES as open } from './shots/Open.cues';
import { CUES as render } from './shots/Render.cues';
import { CUES as speed } from './shots/Speed.cues';
import { CUES as types } from './shots/Types.cues';
import { CUES as browser } from './shots/Browser.cues';
import { CUES as flowcli } from './shots/Flowcli.cues';
import { CUES as dbx } from './shots/Dbx.cues';
import { CUES as outro } from './shots/Outro.cues';

const LOCAL: Record<ShotId, LocalCue[]> = { open, render, speed, types, browser, flowcli, dbx, outro };

export const CUES: Cue[] = [
  ...(Object.keys(LOCAL) as ShotId[]).flatMap((id) => LOCAL[id].map((c) => cue(id, c.at, c.action, c.sound))),
  ...TRANSITION_CUES,
].sort((a, b) => a.frame - b.frame);

// One row per burned-in caption (ids vo1..vo7, vo8a, vo8b), in VO order:
// { id, n, vo, shot, mode, text, from, to, source, fromTime, toTime }; from/to = absolute film frames,
// [from, to). `n` (= `vo`) is the VO line number (1..8). `source` is 'speech' when the window comes
// from CAPTION_OVERRIDES (src/flowmaid/audio/audio.generated.ts), 'lead-tail' otherwise.
export type VoWindow = Caption & { n: number; fromTime: string; toTime: string };
const toWindow = (c: Caption): VoWindow => ({ ...c, n: c.vo, fromTime: fmtTime(c.from), toTime: fmtTime(c.to) });

/** the windows the film actually burns in (CAPTIONS: overrides applied) */
export const VO_WINDOWS: VoWindow[] = CAPTIONS.map(toWindow);
/** the lead/tail windows from VO_LINES only, ignoring CAPTION_OVERRIDES (stable input for fitting) */
export const VO_WINDOWS_DEFAULT: VoWindow[] = CAPTIONS_LEAD_TAIL.map(toWindow);
export { SHOTS };
export { FPS, TOTAL, VO_LINES, CAPTION_MIN_FRAMES, SHOT_ORDER } from './timeline';
