// Audio contract between the Node audio scripts (scripts/audio/fit.mjs writes
// ./audio.generated.ts) and the film (./AudioLayer.tsx plays it; timeline.ts reads
// CAPTION_OVERRIDES). Data only, no React. All frames are FILM frames at 30 fps.

export type AudioClip = {
  /** unique, stable id (e.g. "vo3", "sfx-wipe-228", "music"); used as the clip's React key and timeline name */
  id: string;
  /** path under public/, used with staticFile() (e.g. "audio/vo/vo3.mp3"); forward slashes, no leading slash */
  src: string;
  /** absolute film frame where the clip starts playing (0..TOTAL-1) */
  from: number;
  /** how many film frames it plays (clipped at the film end) */
  durationInFrames: number;
  /** linear gain 0..1 (1 = file as recorded) */
  volume: number;
  /** frames (at 30 fps, i.e. trimBefore / 30 seconds) cut from the start of the FILE; not scaled by playbackRate */
  trimBefore?: number;
  /** 1 = normal speed; e.g. 1.05 plays 5 % faster (pitch preserved by the renderer); covers durationInFrames * playbackRate source frames */
  playbackRate?: number;
  /** linear ramp 0 -> volume over the first N frames of the clip */
  fadeInFrames?: number;
  /** linear ramp volume -> 0 over the last N frames of the clip */
  fadeOutFrames?: number;
};

export type MusicClip = AudioClip & {
  /**
   * Absolute linear gain (same scale as `volume`, NOT a multiplier) the music drops to while any
   * VO clip plays. The duck ramps down over 6 f, ending 2 f before each VO clip starts, and back up
   * over 6 f after the clip's last frame (DUCK_RAMP_FRAMES / DUCK_LEAD_FRAMES in mix.ts).
   * Omit (or set >= volume) for no ducking.
   */
  duckUnderVoTo?: number;
};

/** caption window on screen: [from, to) in absolute film frames */
export type CaptionWindow = { from: number; to: number };
