// AudioLayer — plays the generated audio plan (./audio.generated.ts, written by
// scripts/audio/fit.mjs): voice-over clips, sound effects and an optional music bed that ducks
// under the voice-over. Mounted once in Main.tsx. Draws nothing; with the empty generated file it
// returns null and the film renders exactly as the silent master.
//
// Remotion 4.0.484: <Html5Audio> (the old <Audio> is a deprecated alias), `trimBefore` (was
// `startFrom`), `volume` callback gets the frame counted from the start of this clip's own
// <Sequence> (trimBefore does not shift it). Frames whose volume is 0 are not sent to the mixer,
// which keeps sync (the renderer trims from the first audible frame's media position).
import React from 'react';
import { Html5Audio, Sequence, staticFile } from 'remotion';
import { TOTAL } from '../timeline';
import { MUSIC, SFX_CLIPS, VO_CLIPS } from './audio.generated';
import { clipGainAt, mixPlan, musicGainAt, type PlacedClip } from './mix';

const PLAN = mixPlan(VO_CLIPS, SFX_CLIPS, MUSIC, TOTAL);

const Track: React.FC<{ clip: PlacedClip; kind: 'vo' | 'sfx' | 'music'; gainAt: (g: number) => number }> = ({
  clip, kind, gainAt,
}) => (
  <Sequence from={clip.from} durationInFrames={clip.duration} layout="none" name={`${kind} ${clip.id}`}>
    <Html5Audio
      src={staticFile(clip.src)}
      trimBefore={clip.trimBefore > 0 ? clip.trimBefore : undefined}
      playbackRate={clip.playbackRate}
      // f = frame inside this clip's Sequence -> absolute film frame for the mix maths
      volume={(f) => gainAt(clip.from + f)}
      name={`${kind} ${clip.id}`}
    />
  </Sequence>
);

export const AudioLayer: React.FC = () => {
  const { vo, sfx, music, duckTo } = PLAN;
  if (vo.length === 0 && sfx.length === 0 && !music) return null;
  return (
    <>
      {music ? <Track key="music" clip={music} kind="music" gainAt={(g) => musicGainAt(music, duckTo, vo, g)} /> : null}
      {vo.map((c, i) => (
        <Track key={`vo-${i}-${c.id}`} clip={c} kind="vo" gainAt={(g) => clipGainAt(c, g)} />
      ))}
      {sfx.map((c, i) => (
        <Track key={`sfx-${i}-${c.id}`} clip={c} kind="sfx" gainAt={(g) => clipGainAt(c, g)} />
      ))}
    </>
  );
};
