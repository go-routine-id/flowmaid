// Pure mix maths for AudioLayer.tsx (no React, no remotion imports, deterministic): where each
// clip lands in the film, its linear fade envelope and the music duck under the voice-over.
// Kept separate so Node scripts can bundle and check it (esbuild, like scripts/export-cues.mjs).
import type { AudioClip, MusicClip } from './types';

/** frames the music takes to duck down before a VO clip starts, and to come back after it ends */
export const DUCK_RAMP_FRAMES = 6;
/**
 * the duck is complete this many frames BEFORE a VO clip's first frame. Remotion applies volume
 * changes once per decoded audio buffer (up to 2048 samples = 43 ms = 1.3 f for a mono 16-bit WAV),
 * so a ramp can lag by about one frame; the lead keeps the music fully down when the voice starts.
 */
export const DUCK_LEAD_FRAMES = 2;

const clamp01 = (x: number) => (x < 0 ? 0 : x > 1 ? 1 : x);
/** smoothstep: soft start and end of the duck ramps */
const smooth = (x: number) => {
  const t = clamp01(x);
  return t * t * (3 - 2 * t);
};
const num = (x: unknown, fallback: number) => (typeof x === 'number' && Number.isFinite(x) ? x : fallback);

export type PlacedClip = {
  id: string;
  src: string; // normalised path under public/ (for staticFile)
  from: number; // integer film frame
  duration: number; // integer film frames, > 0, never past `total`
  end: number; // from + duration (exclusive)
  volume: number;
  trimBefore: number; // source frames at 30 fps cut from the file start (0 = none)
  playbackRate: number;
  fadeIn: number;
  fadeOut: number;
};

/** "public/audio/vo/x.mp3", "./audio\\vo\\x.mp3", "/audio/vo/x.mp3" -> "audio/vo/x.mp3" */
export const normaliseSrc = (src: string) =>
  src.replace(/\\/g, '/').replace(/^(\.\/)+/, '').replace(/^\/+/, '').replace(/^public\//, '');

/**
 * Where a clip plays inside a film of `total` frames, or null when it would not be heard
 * (zero/negative volume or duration, or entirely outside the film). A clip that starts before
 * frame 0 keeps sync: the missing head is trimmed from the file instead.
 */
export const placeClip = (c: AudioClip, total: number): PlacedClip | null => {
  const volume = num(c.volume, 0);
  const rate = num(c.playbackRate, 1) > 0 ? num(c.playbackRate, 1) : 1;
  const rawFrom = Math.round(num(c.from, 0));
  const rawEnd = Math.round(num(c.from, 0) + num(c.durationInFrames, 0));
  const from = Math.max(0, rawFrom);
  const end = Math.min(total, rawEnd);
  if (!(volume > 0) || !(end > from) || !c.src) return null;
  const head = from - rawFrom; // film frames lost before frame 0
  return {
    id: c.id,
    src: normaliseSrc(c.src),
    from,
    duration: end - from,
    end,
    volume,
    trimBefore: Math.max(0, num(c.trimBefore, 0)) + head * rate,
    playbackRate: rate,
    fadeIn: Math.max(0, Math.round(num(c.fadeInFrames, 0))),
    fadeOut: Math.max(0, Math.round(num(c.fadeOutFrames, 0))),
  };
};

export const placeAll = (clips: AudioClip[], total: number): PlacedClip[] =>
  clips.map((c) => placeClip(c, total)).filter((c): c is PlacedClip => c !== null);

/**
 * Linear fade envelope 0..1 at clip-local frame `f` (0 = the clip's first frame): rises 0 -> 1
 * over the first `fadeIn` frames, falls 1 -> 0 so that the LAST frame of the clip is 0.
 */
export const fadeEnvelope = (p: PlacedClip, f: number) => {
  let g = 1;
  if (p.fadeIn > 0) g = Math.min(g, f / p.fadeIn);
  if (p.fadeOut > 0) g = Math.min(g, (p.duration - 1 - f) / p.fadeOut);
  return clamp01(g);
};

/**
 * 0..1 "a VO clip is speaking" weight at absolute film frame `g`: 1 from DUCK_LEAD_FRAMES before
 * each VO clip's first frame to its last frame, smooth DUCK_RAMP_FRAMES ramps before and after.
 */
export const voPresenceAt = (vo: PlacedClip[], g: number) => {
  let a = 0;
  for (const s of vo) {
    const up = smooth((g - (s.from - DUCK_LEAD_FRAMES - DUCK_RAMP_FRAMES)) / DUCK_RAMP_FRAMES);
    const down = smooth((s.end - 1 + DUCK_RAMP_FRAMES - g) / DUCK_RAMP_FRAMES);
    a = Math.max(a, Math.min(up, down));
    if (a >= 1) return 1;
  }
  return a;
};

/** music gain at absolute film frame `g`: volume, ducked to duckUnderVoTo under VO, times its fades */
export const musicGainAt = (m: PlacedClip, duckTo: number | undefined, vo: PlacedClip[], g: number) => {
  const f = g - m.from;
  if (f < 0 || f >= m.duration) return 0;
  const low = duckTo === undefined || !Number.isFinite(duckTo) ? m.volume : Math.max(0, Math.min(m.volume, duckTo));
  const level = m.volume + (low - m.volume) * voPresenceAt(vo, g);
  return level * fadeEnvelope(m, f);
};

/** clip gain at absolute film frame `g` (VO / SFX: volume times fades) */
export const clipGainAt = (p: PlacedClip, g: number) => {
  const f = g - p.from;
  if (f < 0 || f >= p.duration) return 0;
  return p.volume * fadeEnvelope(p, f);
};

export type MixPlan = { vo: PlacedClip[]; sfx: PlacedClip[]; music: PlacedClip | null; duckTo: number | undefined };

export const mixPlan = (vo: AudioClip[], sfx: AudioClip[], music: MusicClip | null, total: number): MixPlan => ({
  vo: placeAll(vo, total),
  sfx: placeAll(sfx, total),
  music: music ? placeClip(music, total) : null,
  duckTo: music?.duckUnderVoTo,
});
