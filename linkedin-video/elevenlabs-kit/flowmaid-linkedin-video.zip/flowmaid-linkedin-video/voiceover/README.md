# Naskah voice-over

`lines.json` adalah satu-satunya file untuk mengubah kata-kata, kecepatan, atau pengaturan suara.

- `text`: teks caption (yang tampil di layar)
- `tts_text`: teks yang dibaca suara (singkatan dieja: "S V G", "mermaid J S", "flow C L I", "D B X", "E R D")
- `override` per baris, misalnya `{ "speed": 1.1 }` (0,7 sampai 1,2) atau `{ "voice_settings": { "stability": 0.4 } }`

Caption di video diambil dari `VO_LINES` di `src/flowmaid/timeline.ts`. Jadi kalau kata-kata diubah, ubah dua file:

- vo1 sampai vo7: `text` dan `tts_text` di `lines.json`, lalu `text` baris itu di `VO_LINES`.
- vo8 (dua caption): `text`, `tts_text`, dan `captions[].text` di `lines.json`, lalu `parts[].text` baris 8 di `VO_LINES`.

`npm run vo:fit` memberi peringatan kalau keduanya beda, dan menyebut nama kedua kolomnya.

Setelah mengubah: `npm run vo:tts` (hanya baris yang berubah yang ditagih), lalu `npm run vo:fit`.
