# Naskah voice-over (8 baris, bahasa Inggris)

Sumber kata-kata: `voiceover/lines.json` (file ini hanya ringkasan untuk dibaca dan ditempel).
Waktu di bawah adalah jendela caption SAAT INI dari `src/flowmaid/timeline.ts` (30 frame = 1 detik).
Setelah `npm run vo:fit`, caption pindah mengikuti suara asli.

## Tabel

| Baris | Caption di layar | Jendela caption sekarang | Maks. panjang suara* | Teks untuk suara (`tts_text`) |
|---|---|---|---|---|
| vo1 | flowmaid renders Mermaid diagrams in pure Rust. | frame 4-88 (0,13-2,93 s) | 3,00 s | flowmaid renders Mermaid diagrams in pure Rust. |
| vo2 | Text in, clean SVG out. | 100-224 (3,33-7,47 s) | 4,40 s | Text in, clean S V G out. |
| vo3 | Over a hundred times faster than mermaid.js. | 238-337 (7,93-11,23 s) | 3,63 s | Over a hundred times faster than mermaid J S. |
| vo4 | Twelve diagram types, from flowcharts to sankey. | 353-447 (11,77-14,90 s) | 3,47 s | Twelve diagram types, from flowcharts to sankey. |
| vo5 | In the browser, drag a node, and its edges follow. | 463-595 (15,43-19,83 s) | 5,13 s | In the browser, drag a node, and its edges follow. |
| vo6 | flowcli draws them in your terminal, and redraws when you save. | 623-753 (20,77-25,10 s) | 4,67 s | flow C L I draws them in your terminal, and redraws when you save. |
| vo7 | In dbx, flowmaid lays out your database schema as an ERD. | 769-899 (25,63-29,97 s) | 5,13 s | In D B X, flowmaid lays out your database schema as an E R D. |
| vo8 | flowmaid is open source. / Try it in your browser, or cargo add flowmaid. | 929-985 + 985-1078 (30,97-35,93 s) | 4,83 s | flowmaid is open source. Try it in your browser, or cargo add flowmaid. |

\* Maks. panjang suara = dari awal jendela sampai 6 frame sebelum baris berikutnya mulai (baris terakhir:
sampai frame 1074), tanpa geser waktu. Kalau lebih panjang, `npm run vo:fit` berhenti dan memberi saran
(geser waktu, `speed`, atau kata lebih pendek). Baris paling ketat: vo1, vo8, vo6, vo4.

Total sekitar 413 karakter, jadi satu putaran penuh lewat API sekitar 413 kredit dengan
`eleven_multilingual_v2` (1 kredit per karakter). Rincian: `docs/elevenlabs-api-notes.md`.

## Menempel di web app ElevenLabs (tanpa API key)

Pilihan A (disarankan): satu klip per baris.
1. Model: **Eleven Multilingual v2**. Suara: pilih yang kamu suka (Free plan: hanya suara premade lewat API;
   di web app pakai suara yang boleh kamu pakai).
2. Tempel teks kolom terakhir tabel di atas, satu baris per klip.
3. Unduh dan simpan sebagai `vo1.mp3` ... `vo8.mp3` di `public/audio/vo/import/`.
4. Jalankan `npm run vo:import` lalu `npm run vo:fit`.

Pilihan B: satu rekaman utuh (`full.mp3` di folder yang sama). Tag `<break>` berfungsi di
Multilingual v2 dan Flash v2.5, TIDAK di Eleven v3 / v4 (di sana jeda dibuat dengan tanda baca).
Jeda 0,7 detik antar baris supaya skrip bisa memotong rekaman dengan aman:

```
flowmaid renders Mermaid diagrams in pure Rust. <break time="0.7s" /> Text in, clean S V G out. <break time="0.7s" /> Over a hundred times faster than mermaid J S. <break time="0.7s" /> Twelve diagram types, from flowcharts to sankey. <break time="0.7s" /> In the browser, drag a node, and its edges follow. <break time="0.7s" /> flow C L I draws them in your terminal, and redraws when you save. <break time="0.7s" /> In D B X, flowmaid lays out your database schema as an E R D. <break time="0.7s" /> flowmaid is open source. Try it in your browser, or cargo add flowmaid.
```

Catatan: ada sumber lama yang bilang banyak tag `<break>` dalam satu permintaan bisa membuat suara tidak stabil
(belum terverifikasi). Kalau hasilnya aneh, pakai Pilihan A.

## Pengucapan

- **flowmaid**: "flow-maid". Kalau salah dibaca, tulis `flow maid` di `tts_text`.
- **mermaid.js**: tulis `mermaid J S`.
- **SVG**, **ERD**, **dbx**: dieja `S V G`, `E R D`, `D B X`.
- **flowcli**: `flow C L I`.
- **sankey**: dibaca "SANG-kee". Dengarkan hasilnya; kalau salah, coba ejaan lain di `tts_text` (misalnya `sang key`).
- **cargo add flowmaid**: seperti tertulis. URL tidak dibacakan (link ada di layar).

Gaya suara: tenang dan jelas, dari engineer ke engineer. Tanpa hype, tanpa tanda seru.

## Kalau mengubah kata-kata

Klaim di layar dan di suara harus tetap sesuai daftar klaim di `BRIEF.md`. Ubah `text` dan `tts_text` di
`voiceover/lines.json`, dan teks yang sama di `VO_LINES` di `src/flowmaid/timeline.ts` (caption diambil dari sana).
Untuk vo8 (dua caption): juga `captions[].text` di `lines.json` dan `parts[].text` di `VO_LINES`.
