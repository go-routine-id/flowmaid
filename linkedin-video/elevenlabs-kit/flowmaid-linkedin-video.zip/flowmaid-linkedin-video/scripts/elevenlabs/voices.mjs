// List the voices this ElevenLabs account can use, to pick ELEVENLABS_VOICE_ID.
//   npm run vo:voices                      all voices (yours + premade/default)
//   npm run vo:voices -- --type default    premade voices only (the ones the Free plan can use via the API)
//   npm run vo:voices -- --search narr     filter by text
//   npm run vo:voices -- --json            machine-readable
// API: GET /v2/voices (page_size <= 100, next_page_token, voice_type, search); falls back to GET /v1/voices.
// Needs the key permission "Voices (read)". Free of charge (read only).
import { elevenConfig } from '../lib/env.mjs';
import { createClient } from '../lib/elevenlabs.mjs';
import { parseArgs, runMain, table, UserError } from '../lib/util.mjs';

const USAGE = `
usage: node scripts/elevenlabs/voices.mjs [--type default|personal|workspace|community|saved|non-default] [--search TEXT] [--json]
Lists name, voice_id, category, labels and preview_url. Put the chosen id in .env as ELEVENLABS_VOICE_ID=...
`;

const labelsText = (labels) =>
  labels && typeof labels === 'object'
    ? Object.entries(labels)
        .filter(([, v]) => v)
        .map(([k, v]) => `${k}=${v}`)
        .join(', ')
    : '';

runMain(async () => {
  const args = parseArgs(process.argv.slice(2), { type: 'string', search: 'string', json: 'bool' }, USAGE);
  const cfg = elevenConfig({ requireKey: true });
  const client = createClient(cfg);
  let voices = [];
  try {
    let token;
    for (let page = 0; page < 20; page++) {
      const r = await client.call('GET', '/v2/voices', {
        query: { page_size: 100, voice_type: args.type, search: args.search, next_page_token: token, include_total_count: true },
        what: 'voice list',
      });
      voices.push(...(r.body.voices || []));
      if (!r.body.has_more || !r.body.next_page_token) break;
      token = r.body.next_page_token;
    }
  } catch (e) {
    if (e.status !== 404 && e.status !== 405) throw e;
    // older API surface: /v1/voices (no paging, no filters) -> filter here
    const r = await client.call('GET', '/v1/voices', { what: 'voice list (v1)' });
    voices = (r.body.voices || []).filter((v) => {
      if (args.type === 'default' && v.category !== 'premade') return false;
      if (args.search && !JSON.stringify(v).toLowerCase().includes(args.search.toLowerCase())) return false;
      return true;
    });
  }
  const rows = voices.map((v) => ({
    name: v.name,
    voice_id: v.voice_id,
    category: v.category,
    labels: v.labels || {},
    preview_url: v.preview_url || null,
  }));
  if (args.json) {
    console.log(JSON.stringify(rows, null, 2));
    return;
  }
  if (!rows.length) throw new UserError('no voices found', ['Try without --type / --search.']);
  rows.sort((a, b) => String(a.category).localeCompare(String(b.category)) || String(a.name).localeCompare(String(b.name)));
  console.log(
    table(
      [' ', 'name', 'voice_id', 'category', 'labels', 'preview_url'],
      rows.map((r) => [r.voice_id === cfg.voiceId ? '*' : '', r.name, r.voice_id, r.category, labelsText(r.labels), r.preview_url || '']),
    ),
  );
  console.log(`\n${rows.length} voice(s). * = the voice tts.mjs would use now (${cfg.voiceIdSet ? 'ELEVENLABS_VOICE_ID' : 'default, ELEVENLABS_VOICE_ID not set'}).`);
  if (!rows.some((r) => r.voice_id === cfg.voiceId)) {
    console.log(`note: the current voice id ${cfg.voiceId} is not in this list${args.type || args.search ? ' (filtered)' : ''}.`);
  }
  console.log('Choose one: put  ELEVENLABS_VOICE_ID=<voice_id>  in .env. Free plan: only "premade" voices work through the API.');
});
