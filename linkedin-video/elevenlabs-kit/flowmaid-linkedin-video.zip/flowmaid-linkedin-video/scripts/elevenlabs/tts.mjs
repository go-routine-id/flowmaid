// Generate the voice-over with the ElevenLabs API, one clip per line of voiceover/lines.json.
//   npm run vo:tts                         all lines (cached lines cost nothing)
//   npm run vo:tts -- --only vo3,vo5       just these lines (the others stay as they are)
//   npm run vo:tts -- --dry-run            print the requests and the character count, call nothing
//   npm run vo:tts -- --force              ignore the cache (bills again)
//   npm run vo:tts -- --seed 7             fixed seed for every line (else lines.json defaults/override)
//   npm run vo:tts -- --stitch             request stitching: send previous_request_ids of lines made in this run
//   npm run vo:tts -- --ignore-credits     go on even if the subscription preflight says there are too few credits
//
// API (pkg facts §1): POST /v1/text-to-speech/{voice_id}/with-timestamps?output_format=...
//   body {text, model_id, voice_settings, seed, previous_text, next_text}; response JSON
//   {audio_base64, alignment{characters, character_start_times_seconds, character_end_times_seconds}, normalized_alignment}.
//   language_code is NOT sent (unsupported on multilingual v2). eleven_v4 has no speed/style (skills: "v2/v3
//   models; not supported on Eleven v4"), so they are dropped there; <break> tags are stripped on eleven_v3 and
//   eleven_v4 (no SSML). If a response has no alignment it falls back to POST /v1/forced-alignment (extra cost).
// Writes public/audio/vo/<id>.<ext>, <id>.alignment.json and public/audio/vo/manifest.json.
// Cache: .cache/elevenlabs/tts/<hash>.* keyed by (text, voice, model, format, voice_settings, seed); the
// neighbour context (previous/next text) is NOT in the key, so editing one line never re-bills the others.
import { copyFileSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { elevenConfig } from '../lib/env.mjs';
import { createClient, creditsLeft, forcedAlignment, wordsFromCharAlignment, wordsFromForcedAlignment } from '../lib/elevenlabs.mjs';
import { wavFromPcm16 } from '../lib/ff.mjs';
import { CACHE, MANIFEST, VO_DIR, publicSrc, rel } from '../lib/paths.mjs';
import { clamp, parseArgs, parseIdList, round, runMain, sha256, stableStringify, table, UserError, writeJson } from '../lib/util.mjs';
import { entryFileExists, loadLines, loadManifest, measureSpeech, saveManifest } from '../lib/vo.mjs';

const USAGE = `
usage: node scripts/elevenlabs/tts.mjs [--only vo3,vo5] [--dry-run] [--force] [--seed N] [--stitch] [--skip-voice-check] [--ignore-credits]
Generates public/audio/vo/<id>.mp3 + <id>.alignment.json + manifest.json from voiceover/lines.json.
Settings come from .env: ELEVENLABS_API_KEY, ELEVENLABS_VOICE_ID, ELEVENLABS_MODEL_ID (default eleven_multilingual_v2),
ELEVENLABS_OUTPUT_FORMAT (default mp3_44100_128), ELEVENLABS_BASE_URL (default https://api.elevenlabs.io).
Then run: npm run vo:fit
`;

const TTS_CACHE = join(CACHE, 'tts');
const SPEED_MIN = 0.7; // safe range under every source (pkg facts: help center + MCP say 0.7-1.2; skills says wider)
const SPEED_MAX = 1.2;
const VS_DEFAULTS = { stability: 0.5, similarity_boost: 0.75, style: 0, use_speaker_boost: true };

const stripComments = (o) => (o && typeof o === 'object' ? Object.fromEntries(Object.entries(o).filter(([k]) => !k.startsWith('//'))) : {});

/** credits per character (pkg facts §2: multilingual v2 = 1, flash/turbo = 0.5; others unverified -> assume 1) */
const creditFactor = (model) => (/flash|turbo/.test(model) ? 0.5 : 1);

runMain(async () => {
  const args = parseArgs(
    process.argv.slice(2),
    { only: 'string', force: 'bool', 'dry-run': 'bool', seed: 'number', stitch: 'bool', 'skip-voice-check': 'bool', 'ignore-credits': 'bool' },
    USAGE,
  );
  const dry = args['dry-run'];
  const cfg = elevenConfig({ requireKey: !dry });
  const { defaults, lines } = loadLines();
  const ids = lines.map((l) => l.id);
  const only = args.only ? parseIdList(args.only) : null;
  if (only) {
    const bad = only.filter((id) => !ids.includes(id));
    if (bad.length) throw new UserError(`unknown line id(s): ${bad.join(', ')}`, [`known: ${ids.join(', ')}`]);
  }
  const noSpeedModel = /^eleven_v4/.test(cfg.modelId); // v4: no speed / style (skills text-to-speech/SKILL.md)
  const noBreakModel = /^eleven_v[34]/.test(cfg.modelId); // v3 / v4: no SSML <break> (help center, skills)
  const alignmentUnverified = /^eleven_v[34]/.test(cfg.modelId); // /with-timestamps alignment not documented there
  const warnings = [];

  // ── build one request per line ──
  const reqs = lines.map((l, i) => {
    const vs = { ...VS_DEFAULTS, ...stripComments(defaults.voice_settings), ...stripComments(l.override.voice_settings) };
    let speed = l.override.speed ?? vs.speed ?? defaults.speed ?? 1;
    if (!Number.isFinite(speed)) speed = 1;
    if (speed < SPEED_MIN || speed > SPEED_MAX) {
      warnings.push(`${l.id}: speed ${speed} clamped to ${clamp(speed, SPEED_MIN, SPEED_MAX)} (allowed ${SPEED_MIN}-${SPEED_MAX})`);
      speed = clamp(speed, SPEED_MIN, SPEED_MAX);
    }
    let text = l.tts_text;
    if (noSpeedModel) {
      if (speed !== 1) warnings.push(`${l.id}: ${cfg.modelId} has no speed setting; speed ${speed} ignored (shorten the text or use eleven_multilingual_v2)`);
      delete vs.speed;
      delete vs.style;
    } else vs.speed = round(speed, 3);
    if (noBreakModel) text = text.replace(/<break\b[^>]*\/?>/gi, ' ').replace(/\s+/g, ' ').trim();
    let seed = args.seed ?? l.override.seed ?? defaults.seed;
    if (seed !== undefined && !(Number.isInteger(seed) && seed >= 0 && seed <= 4294967295)) {
      warnings.push(`${l.id}: seed ${seed} is not an integer 0..4294967295; not sent`);
      seed = undefined;
    }
    const body = {
      text,
      model_id: cfg.modelId,
      voice_settings: vs,
      seed,
      previous_text: i > 0 ? lines[i - 1].tts_text : undefined,
      next_text: i < lines.length - 1 ? lines[i + 1].tts_text : undefined,
    };
    // api host in the key: a cache filled by the local mock can never answer a real request
    const key = { v: 1, api: new URL(cfg.baseUrl).host, endpoint: 'with-timestamps', text, voice_id: cfg.voiceId, model_id: cfg.modelId, output_format: cfg.outputFormat, voice_settings: vs, seed };
    const hash = sha256(stableStringify(key)).slice(0, 20);
    const cached = existsSync(join(TTS_CACHE, `${hash}.json`)) && existsSync(join(TTS_CACHE, `${hash}.${cfg.format.ext}`));
    return { line: l, body, hash, cached, selected: !only || only.includes(l.id) };
  });
  const todo = reqs.filter((r) => r.selected);
  const toBill = todo.filter((r) => args.force || !r.cached);
  const chars = toBill.reduce((n, r) => n + r.body.text.length, 0);
  const factor = creditFactor(cfg.modelId);

  console.log(`voice ${cfg.voiceId}${cfg.voiceIdSet ? '' : ` (default: ${'George, premade'}; set ELEVENLABS_VOICE_ID to choose)`}, model ${cfg.modelId}, format ${cfg.outputFormat}${cfg.isMock ? `, base ${cfg.baseUrl} (local mock)` : ''}`);
  for (const w of warnings) console.log(`warning: ${w}`);

  if (dry) {
    for (const r of todo) {
      const hit = r.cached && !args.force;
      console.log(`\n${r.line.id}: ${hit ? 'cache hit, no request' : 'would request'}  (${r.body.text.length} chars, hash ${r.hash})`);
      if (!hit) {
        console.log(`  POST ${cfg.baseUrl}/v1/text-to-speech/${cfg.voiceId}/with-timestamps?output_format=${cfg.outputFormat}`);
        console.log(`  headers: xi-api-key: <hidden>, Content-Type: application/json`);
        console.log(
          `  body: ${JSON.stringify(r.body, null, 2)
            .split('\n')
            .join('\n  ')}`,
        );
      }
    }
    console.log(`\ndry run: ${toBill.length} request(s), ${chars} characters to bill, about ${Math.ceil(chars * factor)} credits${factor === 1 && !/multilingual_v2/.test(cfg.modelId) ? ' (rate for this model unverified; assumed 1 credit/char)' : ''}. Nothing was sent.`);
    if (toBill.length && alignmentUnverified) {
      console.log(
        `note: word timings from /with-timestamps are not documented for ${cfg.modelId}. If a response has none, the script also calls\n` +
          `  POST ${cfg.baseUrl}/v1/forced-alignment once per line (billed like speech-to-text, EXTRA cost, about ${round(chars / 14, 0)} s of audio in total).\n` +
          '  eleven_multilingual_v2 (the default) returns word timings with the speech.',
      );
    }
    return;
  }

  const client = createClient(cfg);
  mkdirSync(TTS_CACHE, { recursive: true });
  mkdirSync(VO_DIR, { recursive: true });

  if (toBill.length) {
    // voice check (free, needs "Voices (read)"): catches a wrong id before anything is billed
    if (!args['skip-voice-check']) {
      try {
        const r = await client.call('GET', '/v2/voices', { query: { voice_ids: cfg.voiceId, page_size: 10 }, retries: 2, what: 'voice check' });
        const found = (r.body.voices || []).find((v) => v.voice_id === cfg.voiceId);
        if (!found) {
          const d = await client.call('GET', '/v2/voices', { query: { voice_type: 'default', page_size: 100 }, retries: 2, what: 'voice list' }).catch(() => null);
          const list = d ? (d.body.voices || []).slice(0, 30).map((v) => `${v.voice_id}  ${v.name} (${v.category})`) : [];
          throw new UserError(`voice ${cfg.voiceId} is not available on this account.`, [
            'Set ELEVENLABS_VOICE_ID in .env to one of your voices (npm run vo:voices). Premade voices:',
            ...list,
            'If you are sure the id is right (for example a shared or workspace voice), add -- --skip-voice-check.',
          ]);
        }
        console.log(`voice ok: ${found.name} (${found.category})`);
      } catch (e) {
        if (e instanceof UserError && !e.status) throw e;
        // a wrong key or no credits stops here; a key without "Voices (read)" (401 missing_permissions) only
        // skips this free check: TTS itself needs "Text to Speech", not "Voices (read)"
        if (e.kind === 'auth' || e.kind === 'quota') throw e;
        const why = e.kind === 'permission' ? `the key has no ${e.permission || 'voices_read'} permission` : e.message.split(':').slice(-1)[0].trim();
        console.log(`note: could not check the voice (${why}); continuing. If the voice id is wrong, the first line fails without being billed.`);
      }
    }
    const credits = await creditsLeft(client);
    if (credits) {
      const need = Math.ceil(chars * factor);
      console.log(`credits left: ${credits.left} of ${credits.limit}${credits.tier ? ` (${credits.tier})` : ''}; this run needs about ${need}`);
      if (credits.left < need) {
        // Free cannot go over its monthly credits; paid plans may (usage-based billing), so only warn there
        const hardStop = !args['ignore-credits'] && (credits.tier === 'free' || credits.canExtend === false);
        const msg = `not enough monthly credits for this run (need about ${need}, have ${credits.left})`;
        if (hardStop) {
          throw new UserError(`${msg}. Nothing was billed.`, [
            'Wait for the monthly reset, buy credits / upgrade, or shorten the run (--only).',
            'On a paid plan with usage-based billing turned on, add -- --ignore-credits to go over the allotment (extra charges).',
          ]);
        }
        console.log(`warning: ${msg}; going on (${args['ignore-credits'] ? '--ignore-credits' : 'this plan may bill usage past the allotment'}).`);
      }
    }
  }

  const manifestOld = loadManifest();
  const oldById = new Map((manifestOld ? manifestOld.lines : []).map((l) => [l.id, l]));
  const out = [];
  const rows = [];
  const madeIds = []; // request ids made in this run, oldest first (for --stitch)
  let billed = 0;
  let faCalls = 0;
  let faSeconds = 0;

  for (const r of reqs) {
    const id = r.line.id;
    if (!r.selected) {
      const keep = oldById.get(id);
      if (keep && entryFileExists(keep)) {
        out.push(keep);
        rows.push([id, '', 'kept', keep.duration_s, `${keep.speech_start_s}-${keep.speech_end_s}`, keep.request_id || '']);
      } else rows.push([id, '', 'MISSING', '', '', '']);
      madeIds.length = 0;
      continue;
    }
    const metaFile = join(TTS_CACHE, `${r.hash}.json`);
    const audioCache = join(TTS_CACHE, `${r.hash}.${cfg.format.ext}`);
    let meta;
    let status;
    if (r.cached && !args.force) {
      meta = JSON.parse(readFileSync(metaFile, 'utf8'));
      status = 'cache';
      madeIds.length = 0;
    } else {
      const body = { ...r.body };
      if (args.stitch && madeIds.length && cfg.modelId !== 'eleven_v3') {
        body.previous_request_ids = madeIds.slice(-3); // newest last, max 3 (docs: request stitching)
        delete body.previous_text; // the ids win over the text anyway
      }
      process.stdout.write(`${id}: generating (${body.text.length} chars)... `);
      const res = await client.call('POST', `/v1/text-to-speech/${encodeURIComponent(cfg.voiceId)}/with-timestamps`, {
        query: { output_format: cfg.outputFormat },
        json: body,
        what: `text-to-speech for ${id}`,
      });
      const b64 = res.body && res.body.audio_base64;
      if (!b64) throw new UserError(`text-to-speech for ${id}: response has no audio_base64`);
      let audio = Buffer.from(b64, 'base64');
      if (cfg.format.rawPcm) audio = wavFromPcm16(audio, cfg.format.sampleRate, 1);
      if (audio.length < 100) throw new UserError(`text-to-speech for ${id}: audio is empty`);
      const billedChars = Number(res.headers.get('x-character-count')) || body.text.length;
      billed += billedChars;
      meta = {
        hash: r.hash,
        voice_id: cfg.voiceId,
        model_id: cfg.modelId,
        output_format: cfg.outputFormat,
        request: body, // no key in here
        request_id: res.requestId,
        characters: billedChars,
        alignment: res.body.alignment || null,
        normalized_alignment: res.body.normalized_alignment || null,
      };
      writeFileSync(audioCache, audio);
      writeJson(metaFile, meta);
      if (res.requestId) madeIds.push(res.requestId);
      status = 'generated';
      console.log(`ok${res.requestId ? ` (request ${res.requestId})` : ''}`);
    }

    // copy into public/audio/vo, drop files of the other kind for the same id
    const file = join(VO_DIR, `${id}.${cfg.format.ext}`);
    for (const ext of ['mp3', 'wav', 'm4a']) if (ext !== cfg.format.ext) rmSync(join(VO_DIR, `${id}.${ext}`), { force: true });
    copyFileSync(audioCache, file);

    // word timings: /with-timestamps alignment, else forced alignment (fallback), else none
    let words = wordsFromCharAlignment(meta.alignment);
    let faNow = false;
    let alignmentSource = words.length ? 'with-timestamps' : 'none';
    if (!words.length) {
      if (meta.forced_alignment) words = wordsFromForcedAlignment(meta.forced_alignment);
      else {
        try {
          console.log(`${id}: the response has no word timings; forced alignment (billed like speech-to-text)...`);
          const fa = await forcedAlignment(client, { audio: readFileSync(file), filename: `${id}.${cfg.format.ext}`, mime: cfg.format.ext === 'mp3' ? 'audio/mpeg' : 'audio/wav', text: r.body.text });
          faCalls++;
          faNow = true;
          meta.forced_alignment = fa;
          writeJson(metaFile, meta);
          words = wordsFromForcedAlignment(fa);
        } catch (e) {
          console.log(`warning: ${id}: no character alignment in the response and forced alignment failed (${e.message}); captions use proportional timing`);
        }
      }
      if (words.length) alignmentSource = 'forced-alignment';
    }
    const alignmentFile = join(VO_DIR, `${id}.alignment.json`);
    writeJson(alignmentFile, {
      id,
      text: r.body.text,
      source: alignmentSource,
      words,
      alignment: meta.alignment,
      normalized_alignment: meta.normalized_alignment,
    });
    const m = await measureSpeech(file, { words });
    if (faNow) faSeconds += m.duration_s;
    const entry = {
      id,
      source: 'elevenlabs-api',
      text: r.line.text,
      tts_text: r.body.text,
      file: publicSrc(file),
      ...m,
      words,
      alignment_source: alignmentSource,
      alignment_file: publicSrc(alignmentFile),
      request_id: meta.request_id || null,
      characters: meta.characters,
      hash: r.hash,
      voice_id: meta.voice_id,
      model_id: meta.model_id,
      output_format: meta.output_format,
      voice_settings: r.body.voice_settings,
      seed: r.body.seed ?? null,
    };
    out.push(entry);
    rows.push([id, r.body.text.length, status, m.duration_s, `${m.speech_start_s}-${m.speech_end_s}`, entry.request_id || '']);
  }

  saveManifest(
    { version: 1, source: 'elevenlabs-api', voice_id: cfg.voiceId, model_id: cfg.modelId, output_format: cfg.outputFormat, lines: out },
    ids,
  );
  console.log(`\n${table(['line', 'chars', 'status', 'duration_s', 'speech_s', 'request_id'], rows)}`);
  console.log(`\nwrote ${rel(MANIFEST)}; billed this run: ${billed} characters${billed || faCalls ? '' : ' (everything came from the cache)'}${faCalls ? ` + ${faCalls} forced-alignment call(s) on about ${round(faSeconds, 1)} s of audio (billed like speech-to-text)` : ''}.`);
  const missing = rows.filter((r) => r[2] === 'MISSING').map((r) => r[0]);
  if (missing.length) console.log(`still missing: ${missing.join(', ')} (run without --only to make them)`);
  console.log('next: npm run vo:fit');
});
