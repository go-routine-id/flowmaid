// Generate the sound-effect library with the ElevenLabs sound-generation API: one file per category,
// public/audio/sfx/library/<category>.mp3, from the prompts in scripts/audio/sfx-categories.json.
//   npm run sfx:gen                    categories used by enabled entries of public/audio/sfx/plan.json
//   npm run sfx:gen -- --only pop,whoosh
//   npm run sfx:gen -- --all           every category
//   npm run sfx:gen -- --dry-run       print the requests and an estimate, call nothing
//   npm run sfx:gen -- --force         regenerate files this script made before (bills again)
// Your own files always win: a library file this script did not make is never overwritten.
// API (pkg facts §4): POST /v1/sound-generation?output_format=mp3_44100_128
//   body {text, duration_seconds 0.5..30 | null (auto), prompt_influence 0..1, model_id}; response: audio bytes.
//   Cost: about 100 credits per call on auto duration; fixed durations are billed per second
//   (sources disagree: 11 / 20 / 40 credits per second, UNVERIFIED) -> the estimate shows a range.
//   Free-plan access to this endpoint is UNVERIFIED: a 402/403 means "use your own files". A key without the
//   Sound Effects permission gets HTTP 401 missing_permissions (live API; the docs say 403).
// Cache: .cache/elevenlabs/sfx/<hash>.mp3 by (prompt, duration, influence, model, format).
import { copyFileSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { elevenConfig, outputFormatInfo } from '../lib/env.mjs';
import { createClient } from '../lib/elevenlabs.mjs';
import { CACHE, SFX_CATEGORIES, SFX_GENERATED, SFX_LIBRARY, SFX_PLAN, rel } from '../lib/paths.mjs';
import { clamp, parseArgs, parseIdList, readJson, runMain, sha256, stableStringify, table, UserError, writeJson } from '../lib/util.mjs';

const USAGE = `
usage: node scripts/elevenlabs/sfx.mjs [--only pop,whoosh] [--all] [--dry-run] [--force]
Writes public/audio/sfx/library/<category>.mp3 for categories that have no file yet. Then: npm run vo:fit
`;

const SFX_CACHE = join(CACHE, 'sfx');
const EXTS = ['wav', 'mp3', 'm4a'];

runMain(async () => {
  const args = parseArgs(process.argv.slice(2), { only: 'string', all: 'bool', 'dry-run': 'bool', force: 'bool' }, USAGE);
  const dry = args['dry-run'];
  const cfg = elevenConfig({ requireKey: !dry });
  const catCfg = readJson(SFX_CATEGORIES);
  const cats = catCfg.categories || {};
  const gen = catCfg.generation || {};
  const fmtName = gen.output_format || 'mp3_44100_128';
  const fmt = outputFormatInfo(fmtName);
  if (!fmt || fmt.unsupported) throw new UserError(`sfx-categories.json generation.output_format "${fmtName}" is not supported (use mp3_44100_128)`);

  let wanted;
  if (args.only) {
    wanted = parseIdList(args.only, '');
    const bad = wanted.filter((c) => !cats[c]);
    if (bad.length) throw new UserError(`unknown categor${bad.length > 1 ? 'ies' : 'y'}: ${bad.join(', ')}`, [`known: ${Object.keys(cats).join(', ')}`]);
  } else if (args.all) wanted = Object.keys(cats);
  else {
    if (!existsSync(SFX_PLAN)) throw new UserError(`no ${rel(SFX_PLAN)} yet: run npm run sfx:plan first (or use --all / --only)`);
    const plan = readJson(SFX_PLAN);
    wanted = [...new Set((plan.entries || []).filter((e) => e.enabled && e.category && !e.file).map((e) => e.category))];
  }

  const generated = existsSync(SFX_GENERATED) ? readJson(SFX_GENERATED) : {};
  const jobs = [];
  const rows = [];
  for (const c of wanted) {
    const def = cats[c];
    const duration = def.duration_seconds === null || def.duration_seconds === undefined ? null : clamp(Number(def.duration_seconds), 0.5, 30);
    const body = {
      text: def.prompt,
      duration_seconds: duration,
      prompt_influence: clamp(Number(def.prompt_influence ?? gen.prompt_influence ?? 0.3), 0, 1),
      model_id: cfg.sfxModelId,
    };
    const hash = sha256(stableStringify({ v: 1, api: new URL(cfg.baseUrl).host, ...body, output_format: fmtName })).slice(0, 20);
    const existing = EXTS.map((e) => join(SFX_LIBRARY, `${c}.${e}`)).find((f) => existsSync(f));
    const mine = generated[c];
    // a file counts as ours only if its bytes are what this script wrote (else you replaced it)
    const ours = existing && mine && existing.endsWith(`${c}.${fmt.ext}`) && mine.sha256 === sha256(readFileSync(existing));
    if (existing && !ours) {
      rows.push([c, 'own file, kept', rel(existing)]);
      continue;
    }
    if (existing && mine && mine.hash === hash && !args.force) {
      rows.push([c, 'up to date', rel(existing)]);
      continue;
    }
    jobs.push({ c, body, hash });
  }

  const credits = jobs.reduce((n, j) => n + (j.body.duration_seconds === null ? 100 : j.body.duration_seconds * 20), 0);
  const creditsHigh = jobs.reduce((n, j) => n + (j.body.duration_seconds === null ? 100 : j.body.duration_seconds * 40), 0);
  if (dry) {
    for (const j of jobs) {
      const cached = existsSync(join(SFX_CACHE, `${j.hash}.${fmt.ext}`));
      console.log(`\n${j.c}: ${cached ? 'cache hit, no request' : 'would request'}`);
      if (!cached) {
        console.log(`  POST ${cfg.baseUrl}/v1/sound-generation?output_format=${fmtName}   (xi-api-key: <hidden>)`);
        console.log(`  body: ${JSON.stringify(j.body)}`);
      }
    }
    if (rows.length) console.log(`\n${table(['category', 'status', 'file'], rows)}`);
    console.log(`\ndry run: ${jobs.length} sound(s), roughly ${Math.round(credits)}-${Math.round(creditsHigh)} credits (per-second rate unverified). Nothing was sent.`);
    return;
  }

  const client = createClient(cfg);
  mkdirSync(SFX_CACHE, { recursive: true });
  mkdirSync(SFX_LIBRARY, { recursive: true });
  for (const j of jobs) {
    const cacheFile = join(SFX_CACHE, `${j.hash}.${fmt.ext}`);
    let status = 'cache';
    if (!existsSync(cacheFile) || args.force) {
      process.stdout.write(`${j.c}: generating... `);
      try {
        const r = await client.call('POST', '/v1/sound-generation', { query: { output_format: fmtName }, json: j.body, expect: 'binary', what: `sound effect "${j.c}"` });
        if (!r.body || r.body.length < 100) throw new UserError(`sound effect "${j.c}": empty audio`);
        writeFileSync(cacheFile, r.body);
        console.log('ok');
        status = 'generated';
      } catch (e) {
        console.log('failed');
        if (e.status === 402 || e.status === 403 || e.kind === 'permission' || e.kind === 'paid_plan') {
          const at = e.lines.findIndex((l) => l.startsWith('request id:'));
          e.lines.splice(at < 0 ? e.lines.length : at, 0,
            e.kind === 'permission'
              ? 'Or skip ElevenLabs sound effects and use your own files:'
              : 'Sound effects may not be available for this plan or key. Use your own files instead:',
            `put ${j.c}.mp3 (or .wav) into public/audio/sfx/library/ - see public/audio/sfx/library/README.md`,
          );
        }
        throw e;
      }
    }
    const out = join(SFX_LIBRARY, `${j.c}.${fmt.ext}`);
    for (const e of EXTS) if (e !== fmt.ext) rmSync(join(SFX_LIBRARY, `${j.c}.${e}`), { force: true });
    copyFileSync(cacheFile, out);
    generated[j.c] = { file: `${j.c}.${fmt.ext}`, hash: j.hash, sha256: sha256(readFileSync(out)), prompt: j.body.text, duration_seconds: j.body.duration_seconds, model_id: j.body.model_id };
    writeJson(SFX_GENERATED, generated);
    rows.push([j.c, status, rel(out)]);
  }
  console.log(`\n${table(['category', 'status', 'file'], rows)}`);
  console.log(`\n${rel(SFX_GENERATED)} lists the files this script made (others are yours and never overwritten). next: npm run vo:fit`);
});
