// Two-pass EBU R128 loudness normalisation of the rendered film with ffmpeg's loudnorm filter.
//   npm run audio:loudnorm
//   node scripts/audio/loudnorm.mjs --in out/x.mov --out out/x.mp4 [--target -16] [--tp -1.5] [--lra 11]
// Input: out/flowmaid-promo-audio.raw.mov (npm run render:audio), else out/flowmaid-promo-audio.raw.mp4.
// Output: out/flowmaid-promo-audio.mp4 - the video stream is copied untouched, audio is AAC 48 kHz.
// Targets come from public/audio/mix.json "loudness" (default -16 LUFS integrated, -1.5 dBTP, LRA 11).
// Pass 1 measures, pass 2 applies a linear gain with the measured values (linear=true), pass 3
// measures the result and prints it. Uses Remotion's bundled ffmpeg if it has loudnorm, else the
// system ffmpeg.
import { existsSync, renameSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { probe, resolveTool, run } from '../lib/ff.mjs';
import { loadMix, num } from '../lib/mix.mjs';
import { OUT, ROOT, rel } from '../lib/paths.mjs';
import { parseArgs, round, runMain, table, UserError } from '../lib/util.mjs';

const USAGE = `
usage: node scripts/audio/loudnorm.mjs [--in FILE] [--out FILE] [--target LUFS] [--tp dBTP] [--lra LU]
Default: out/flowmaid-promo-audio.raw.mov (or .raw.mp4) -> out/flowmaid-promo-audio.mp4, targets from public/audio/mix.json.
`;

/** the last {...} JSON block loudnorm prints to stderr */
const parseLoudnorm = (stderr) => {
  const i = stderr.lastIndexOf('{');
  const j = stderr.lastIndexOf('}');
  if (i < 0 || j < i) return null;
  try {
    return JSON.parse(stderr.slice(i, j + 1));
  } catch {
    return null;
  }
};

const abs = (p) => (/^([a-zA-Z]:)?[\\/]/.test(p) ? p : join(ROOT, p));

runMain(async () => {
  const args = parseArgs(process.argv.slice(2), { in: 'string', out: 'string', target: 'number', tp: 'number', lra: 'number' }, USAGE);
  const mix = loadMix();
  const I = args.target ?? num(mix.loudness.integrated_lufs, -16);
  const TP = args.tp ?? num(mix.loudness.true_peak_dbtp, -1.5);
  const LRA = args.lra ?? num(mix.loudness.lra, 11);
  const bitrate = String(mix.loudness.aac_bitrate || '192k');
  const candidates = args.in ? [abs(args.in)] : [join(OUT, 'flowmaid-promo-audio.raw.mov'), join(OUT, 'flowmaid-promo-audio.raw.mp4')];
  const input = candidates.find((f) => existsSync(f));
  if (!input) {
    throw new UserError(`no rendered film found (${candidates.map(rel).join(' or ')}).`, ['Render it first: npm run render:audio   (or npm run render:final for fit + render + loudnorm)']);
  }
  const output = args.out ? abs(args.out) : join(OUT, 'flowmaid-promo-audio.mp4');
  if (output === input) throw new UserError('--out must differ from --in');

  const info = await probe(input);
  if (!info.audio) {
    throw new UserError(`${rel(input)} has no audio track.`, [
      'Was it rendered with npm run render:audio (not render:silent / --muted)? Is src/flowmaid/audio/audio.generated.ts filled (npm run vo:fit)?',
    ]);
  }
  let ff;
  try {
    ff = resolveTool('ffmpeg', { needFilters: ['loudnorm', 'aresample'] });
  } catch (e) {
    e.lines.unshift('loudnorm needs an ffmpeg with the loudnorm filter (Remotion\'s bundled one has it).');
    throw e;
  }
  console.log(`input  ${rel(input)} (${round(info.duration, 2)} s, ${info.audio.codec} ${info.audio.sampleRate} Hz, ${info.audio.channels} ch)`);
  console.log(`target ${I} LUFS integrated, ${TP} dBTP true peak, LRA ${LRA}; using ${ff.label}`);

  // pass 1: measure
  const p1 = await run(ff, ['-hide_banner', '-nostats', '-i', input, '-map', '0:a:0', '-af', `loudnorm=I=${I}:TP=${TP}:LRA=${LRA}:print_format=json`, '-f', 'null', '-']);
  const m1 = parseLoudnorm(p1.stderr);
  if (!m1) throw new UserError('could not read the loudnorm measurement (pass 1)', [p1.stderr.trim().split('\n').slice(-5).join('\n  ')]);
  if (!Number.isFinite(Number(m1.input_i))) {
    throw new UserError(`the audio track is silent (integrated loudness ${m1.input_i}).`, ['Check src/flowmaid/audio/audio.generated.ts (npm run vo:fit) and render again.']);
  }

  // pass 2: apply (linear gain from the measurement), keep the video stream as it is
  const tmp = `${output}.tmp-${process.pid}.mp4`;
  const filter =
    `loudnorm=I=${I}:TP=${TP}:LRA=${LRA}:measured_I=${m1.input_i}:measured_TP=${m1.input_tp}:measured_LRA=${m1.input_lra}` +
    `:measured_thresh=${m1.input_thresh}:offset=${m1.target_offset}:linear=true:print_format=json,aresample=48000`;
  const vArgs = info.video ? ['-map', '0:v:0', '-c:v', 'copy'] : [];
  try {
    const p2 = await run(ff, ['-hide_banner', '-nostats', '-y', '-i', input, ...vArgs, '-map', '0:a:0', '-af', filter, '-c:a', 'aac', '-b:a', bitrate, '-ar', '48000', '-movflags', '+faststart', tmp]);
    const m2 = parseLoudnorm(p2.stderr) || {};
    rmSync(output, { force: true });
    renameSync(tmp, output);
    // pass 3: measure the result
    const p3 = await run(ff, ['-hide_banner', '-nostats', '-i', output, '-map', '0:a:0', '-af', `loudnorm=I=${I}:TP=${TP}:LRA=${LRA}:print_format=json`, '-f', 'null', '-']);
    const m3 = parseLoudnorm(p3.stderr) || {};
    console.log(
      `\n${table(
        ['', 'integrated LUFS', 'true peak dBTP', 'LRA LU', 'threshold'],
        [
          ['before', m1.input_i, m1.input_tp, m1.input_lra, m1.input_thresh],
          ['after', m3.input_i, m3.input_tp, m3.input_lra, m3.input_thresh],
          ['target', I, TP, LRA, ''],
        ],
      )}`,
    );
    console.log(`normalization: ${m2.normalization_type || 'unknown'}${m2.normalization_type === 'dynamic' ? ' (the target needed more than a plain gain change; loudnorm compressed the peaks)' : ''}`);
    const off = Math.abs(Number(m3.input_i) - I);
    if (Number.isFinite(off) && off > 1) console.log(`warning: result is ${round(off, 1)} LU from the target (short or very quiet audio measures less precisely)`);
    console.log(`\nwrote ${rel(output)}`);
  } finally {
    rmSync(tmp, { force: true });
  }
});
