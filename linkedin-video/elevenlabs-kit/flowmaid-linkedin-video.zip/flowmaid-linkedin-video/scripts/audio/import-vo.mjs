// Import a voice-over made in the ElevenLabs WEB app (or recorded yourself) instead of the API.
// Put the files in public/audio/vo/import/ and run  npm run vo:import :
//   per line:  vo1.mp3 ... vo8.mp3   (mp3, wav or m4a; one file per line of voiceover/lines.json)
//   one take:  full.mp3              (all lines in order with a 0.7 s pause between lines, see voiceover/SCRIPT.md;
//                                     split on the pauses)
// Each line is trimmed to its speech (small pad kept), converted to 48 kHz mono WAV as
// public/audio/vo/<id>.wav, measured, and listed in public/audio/vo/manifest.json (source "import").
//   --align                refine with ElevenLabs forced alignment (needs ELEVENLABS_API_KEY; billed like
//                          speech-to-text): gives word timings (better caption splits) and, for a full take,
//                          cuts between the last word of one line and the first word of the next.
//                          With --dry-run nothing is sent (it says what would be billed). Responses are cached
//                          in .cache/elevenlabs/forced-alignment/ by audio + text, so a re-run is free.
//                          If the call fails, the import goes on without it (pauses / waveform only).
//   --noise -40            level in dBFS counted as silence (raise to -35 for a noisy recording)
//   --min-silence 0.35     shortest pause (s) that counts as a line break in a full take (detection threshold;
//                          SCRIPT.md asks for 0.7 s pauses)
//   --splits 3.4,6.1,...   cut a full take at these times (s) instead of detecting pauses
//   --only vo3             per-line mode: import just these lines, keep the rest of the manifest
//   --mode lines|full      when both kinds of files are present
//   --dry-run              print what would be cut, write nothing
// Then: npm run vo:fit
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync } from 'node:fs';
import { extname, join } from 'node:path';
import { elevenConfig } from '../lib/env.mjs';
import { ApiError, createClient, forcedAlignment, wordsFromForcedAlignment } from '../lib/elevenlabs.mjs';
import { detectSilences, probe, soundSegments, toWav } from '../lib/ff.mjs';
import { CACHE, IMPORT_DIR, MANIFEST, OUT, VO_DIR, publicSrc, rel } from '../lib/paths.mjs';
import { normWord, parseArgs, parseIdList, readJson, round, runMain, sha256, stableStringify, table, UserError, writeJson } from '../lib/util.mjs';
import { entryFileExists, loadLines, loadManifest, measureSpeech, saveManifest } from '../lib/vo.mjs';

const USAGE = `
usage: node scripts/audio/import-vo.mjs [--align] [--noise -40] [--min-silence 0.35] [--splits t1,t2,...]
                                        [--only vo3,vo5] [--mode lines|full] [--full FILE] [--dry-run]
Reads public/audio/vo/import/vo1.mp3 ... vo8.mp3 (or one full.mp3), writes public/audio/vo/<id>.wav + manifest.json.
`;

const EXTS = ['.mp3', '.wav', '.m4a'];
const PAD_START = 0.08; // s kept before the speech
const PAD_END = 0.25; // s kept after the speech
const MIME = { '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.m4a': 'audio/mp4' };
const FA_CACHE = join(CACHE, 'forced-alignment');

/** print an API failure as a warning (message + advice lines) */
const warnApi = (what, e) => {
  console.log(`warning: ${what} failed: ${e.message}`);
  for (const l of e.lines || []) console.log(`  ${l}`);
};

/** files in import/ by lower-case base name: {vo1: '/.../vo1.mp3', full: ...} */
const scanImport = () => {
  const out = {};
  if (!existsSync(IMPORT_DIR)) return out;
  for (const f of readdirSync(IMPORT_DIR)) {
    const ext = extname(f).toLowerCase();
    if (!EXTS.includes(ext)) continue;
    const base = f.slice(0, -ext.length).toLowerCase();
    if (!out[base]) out[base] = join(IMPORT_DIR, f);
  }
  return out;
};

/** sound stretches of a file, ignoring blips shorter than 60 ms. label: how to name the file in errors */
const speechOf = async (file, noiseDb, label) => {
  const det = await detectSilences(file, { noiseDb, minDur: 0.05 });
  const segs = soundSegments(det).filter((s) => s.end - s.start >= 0.06);
  if (!segs.length) throw new UserError(`${label || rel(file)} is silent at ${noiseDb} dB`, ['Check the file or lower --noise (e.g. -50).']);
  return { start: segs[0].start, end: segs[segs.length - 1].end, duration: det.duration };
};

/**
 * pauses BETWEEN sounds (never the silence before the first or after the last sound; an mp3's
 * container duration can be a little longer than its decoded audio, so "ends at the file end"
 * is not a safe test). Returns {duration, pauses: [{start, end}]}.
 */
const pausesOf = async (file, noiseDb, minSilence) => {
  const det = await detectSilences(file, { noiseDb, minDur: minSilence });
  const segs = soundSegments(det).filter((s) => s.end - s.start >= 0.06);
  const pauses = [];
  for (let i = 0; i + 1 < segs.length; i++) pauses.push({ start: segs[i].end, end: segs[i + 1].start });
  return { duration: det.duration, pauses };
};

/**
 * map forced-alignment words onto the lines in order (normalized text, small look-ahead).
 * Returns per line [{word,start_s,end_s}] in absolute file time, or null if a line got no word.
 */
const wordsPerLine = (faWords, lines) => {
  const fa = faWords.map((w) => ({ ...w, n: normWord(w.word) })).filter((w) => w.n);
  let j = 0;
  const out = lines.map((l) => {
    const got = [];
    for (const tok of l.tts_text.split(/\s+/).map(normWord).filter(Boolean)) {
      for (let k = j; k < Math.min(fa.length, j + 4); k++) {
        if (fa[k].n === tok) {
          got.push(fa[k]);
          j = k + 1;
          break;
        }
      }
    }
    return got.map(({ n, ...w }) => w);
  });
  return out.every((w) => w.length) ? out : null;
};

runMain(async () => {
  const args = parseArgs(
    process.argv.slice(2),
    { align: 'bool', noise: 'number', 'min-silence': 'number', splits: 'string', only: 'string', mode: 'string', full: 'string', 'dry-run': 'bool' },
    USAGE,
  );
  const dry = args['dry-run'];
  const noiseDb = args.noise ?? -40;
  const minSilence = args['min-silence'] ?? 0.35;
  const { lines } = loadLines();
  const ids = lines.map((l) => l.id);
  const files = scanImport();
  const fullFile = args.full ? args.full : files.full || null;
  const perLine = ids.filter((id) => files[id]);
  let mode = args.mode;
  if (!mode) {
    if (fullFile && perLine.length) {
      throw new UserError('public/audio/vo/import/ has both full.* and per-line files.', ['Pick one: npm run vo:import -- --mode full   or   --mode lines']);
    }
    mode = fullFile ? 'full' : 'lines';
  }
  if (mode === 'lines' && !perLine.length) {
    throw new UserError(`no voice-over files in ${rel(IMPORT_DIR)}/`, [
      `Per line: ${ids.map((id) => `${id}.mp3`).join(', ')} (mp3, wav or m4a)`,
      'or one take with all lines in order: full.mp3',
      'In the ElevenLabs web app paste the tts_text of each line from voiceover/lines.json and download each clip.',
    ]);
  }
  if (mode === 'full' && (!fullFile || !existsSync(fullFile))) throw new UserError(`full take not found${fullFile ? `: ${fullFile}` : ` (${rel(IMPORT_DIR)}/full.mp3)`}`);

  // forced alignment (--align): cached by (API host, source audio, cut, text); never called in --dry-run
  let client = null;
  let cfg = null;
  if (args.align) {
    cfg = elevenConfig({ requireKey: false });
    if (!cfg.hasKey && !dry) {
      throw new UserError('--align needs ELEVENLABS_API_KEY (forced alignment is an API call).', ['Run without --align: captions are then timed from the waveform alone.']);
    }
    if (!cfg.hasKey) console.log('note: ELEVENLABS_API_KEY is not set; the real run with --align needs it.');
    client = createClient(cfg);
  }
  const srcHashes = new Map();
  const faKey = (src, cut, text) => {
    if (!srcHashes.has(src)) srcHashes.set(src, sha256(readFileSync(src)));
    return sha256(stableStringify({ v: 1, api: new URL(cfg.baseUrl).host, audio: srcHashes.get(src), cut, text })).slice(0, 20);
  };
  const faCached = (key) => {
    const f = join(FA_CACHE, `${key}.json`);
    return existsSync(f) ? readJson(f) : null;
  };
  let faBilled = { calls: 0, seconds: 0 };
  let fullAlignPlanned = false; // dry run: the full-take alignment would be called
  /** forced alignment with the cache; returns the response or throws ApiError */
  const align = async (key, { audio, filename, mime, text, seconds }) => {
    const hit = faCached(key);
    if (hit) return hit;
    const fa = await forcedAlignment(client, { audio, filename, mime, text });
    mkdirSync(FA_CACHE, { recursive: true });
    writeJson(join(FA_CACHE, `${key}.json`), fa);
    faBilled = { calls: faBilled.calls + 1, seconds: faBilled.seconds + seconds };
    return fa;
  };

  const tmpDir = join(OUT, `.import-tmp-${process.pid}`);
  mkdirSync(tmpDir, { recursive: true });
  const results = [];
  try {
    if (mode === 'lines') {
      const only = args.only ? parseIdList(args.only) : ids;
      const bad = only.filter((id) => !ids.includes(id));
      if (bad.length) throw new UserError(`unknown line id(s): ${bad.join(', ')}`);
      const missing = only.filter((id) => !files[id]);
      if (missing.length) {
        throw new UserError(`missing in ${rel(IMPORT_DIR)}/: ${missing.map((id) => `${id}.mp3`).join(', ')}`, [
          `found: ${perLine.map((id) => rel(files[id])).join(', ')}`,
          `To import only some lines: npm run vo:import -- --only ${perLine.join(',')}`,
        ]);
      }
      for (const id of only) {
        const src = files[id];
        const sp = await speechOf(src, noiseDb, rel(src));
        const cutStart = Math.max(0, sp.start - PAD_START);
        const cutEnd = Math.min(sp.duration, sp.end + PAD_END);
        results.push({ id, src, srcFile: src, cut: [round(cutStart, 3), round(cutEnd, 3)], cutStart, cutEnd, srcDuration: sp.duration });
      }
    } else {
      if (args.only) throw new UserError('--only works with per-line files; a full take always holds every line.');
      const { duration } = await probe(fullFile);
      let cuts = null;
      let how = '';
      if (args.splits) {
        cuts = args.splits.split(/[\s,]+/).filter(Boolean).map(Number);
        if (cuts.some((x) => !Number.isFinite(x) || x <= 0 || x >= duration)) throw new UserError(`--splits must be times in seconds between 0 and ${round(duration, 2)}`);
        cuts.sort((a, b) => a - b);
        how = '--splits';
      }
      const { pauses: internal } = await pausesOf(fullFile, noiseDb, minSilence);
      let alignWords = null;
      if (!cuts && client) {
        const text = lines.map((l) => l.tts_text).join(' ');
        const key = faKey(fullFile, null, text);
        let fa = faCached(key);
        if (fa) console.log('forced alignment of the full take: from the cache (no request, nothing billed)');
        else if (dry) {
          fullAlignPlanned = true;
          console.log(
            `dry run: --align would call POST ${cfg.baseUrl}/v1/forced-alignment once for the full take (${round(duration, 1)} s of audio,\n` +
              '  billed like speech-to-text). Not called now: the cuts below come from the pauses; the real run may cut between words instead.',
          );
        } else {
          console.log(`forced alignment of the full take (${round(duration, 1)} s of audio, billed like speech-to-text)...`);
          try {
            fa = await align(key, { audio: readFileSync(fullFile), filename: `full${extname(fullFile).toLowerCase()}`, mime: MIME[extname(fullFile).toLowerCase()], text, seconds: duration });
          } catch (e) {
            if (!(e instanceof ApiError)) throw e;
            warnApi('forced alignment of the full take', e);
            console.log('  going on without it: splitting on pauses (check the cuts; --splits gives them by hand).');
            client = null; // no further calls with this key in this run
          }
        }
        if (fa) alignWords = wordsPerLine(wordsFromForcedAlignment(fa), lines);
        if (fa && alignWords) {
          // the alignment decides WHICH pause separates two lines; the cut goes in the middle of the
          // nearest real pause (within 1 s), so a slightly-off alignment never cuts into a word
          cuts = [];
          const used = new Set();
          for (let i = 0; i + 1 < lines.length; i++) {
            const a = alignWords[i][alignWords[i].length - 1].end_s;
            const b = alignWords[i + 1][0].start_s;
            const mid = (a + b) / 2;
            let best = null;
            internal.forEach((p, k) => {
              if (used.has(k)) return;
              const d = mid < p.start ? p.start - mid : mid > p.end ? mid - p.end : 0;
              if (d <= 1 && (!best || d < best.d)) best = { k, d };
            });
            if (best) used.add(best.k);
            const cut = best ? (internal[best.k].start + internal[best.k].end) / 2 : mid;
            cuts.push(Math.max(cut, i ? cuts[i - 1] + 0.1 : 0.1));
          }
          how = 'forced alignment (snapped to pauses)';
        } else if (fa) console.log('warning: the alignment did not match the script; splitting on pauses instead');
      }
      if (!cuts) {
        const need = lines.length - 1;
        const list = internal.map((s) => `${round(s.start, 2)}-${round(s.end, 2)} s`).join(', ') || 'none';
        if (internal.length < need) {
          throw new UserError(`found ${internal.length} pause(s) of at least ${minSilence} s below ${noiseDb} dB, need ${need} to split ${lines.length} lines.`, [
            `pauses found: ${list}`,
            `Try a shorter --min-silence (e.g. ${round(Math.max(0.15, minSilence - 0.1), 2)}) or a higher --noise (e.g. ${noiseDb + 5}),`,
            '--align (forced alignment, needs an API key), or give the cut times: --splits 3.4,6.1,...',
            'Or export one file per line from the web app (vo1.mp3 ... vo8.mp3).',
          ]);
        }
        const chosen = internal
          .map((s, i) => ({ ...s, i, len: s.end - s.start }))
          .sort((a, b) => b.len - a.len || a.i - b.i)
          .slice(0, need)
          .sort((a, b) => a.start - b.start);
        if (internal.length > need) console.log(`note: ${internal.length} pauses found, using the ${need} longest (${chosen.map((s) => `${round(s.start, 2)}-${round(s.end, 2)}`).join(', ')})`);
        cuts = chosen.map((s) => (s.start + s.end) / 2);
        how = `pauses >= ${minSilence} s below ${noiseDb} dB`;
      }
      if (cuts.length !== lines.length - 1) throw new UserError(`need ${lines.length - 1} cut points for ${lines.length} lines, got ${cuts.length}`);
      console.log(`full take ${rel(fullFile)} (${round(duration, 2)} s) split by ${how} at: ${cuts.map((c) => round(c, 2)).join(', ')} s`);
      const bounds = [0, ...cuts, duration];
      for (let i = 0; i < lines.length; i++) {
        const seg = join(tmpDir, `${lines[i].id}-seg.wav`);
        await toWav(fullFile, seg, { start: bounds[i], end: bounds[i + 1] });
        const sp = await speechOf(seg, noiseDb, `${lines[i].id} (${round(bounds[i], 2)}-${round(bounds[i + 1], 2)} s of the full take)`);
        const r = { id: lines[i].id, src: seg, cutStart: Math.max(0, sp.start - PAD_START), cutEnd: Math.min(sp.duration, sp.end + PAD_END), srcDuration: sp.duration, segOffset: bounds[i] };
        r.srcFile = fullFile; // cache key: the full take + the absolute cut
        r.cut = [round(bounds[i] + r.cutStart, 3), round(bounds[i] + r.cutEnd, 3)];
        if (alignWords) {
          // absolute full-take times -> times inside the final trimmed file
          const off = bounds[i] + r.cutStart;
          r.words = alignWords[i].map((w) => ({ word: w.word, start_s: round(w.start_s - off, 3), end_s: round(w.end_s - off, 3) }));
        }
        results.push(r);
      }
      // sanity: speaking rate per segment should be similar
      const rates = results.map((r, i) => lines[i].tts_text.length / Math.max(0.1, r.cutEnd - r.cutStart));
      const med = [...rates].sort((a, b) => a - b)[Math.floor(rates.length / 2)];
      rates.forEach((x, i) => {
        if (x > med * 1.8 || x < med / 1.8) {
          console.log(`warning: ${lines[i].id} looks ${x > med ? 'too short' : 'too long'} for its text (${round(x, 1)} chars/s, typical ${round(med, 1)}). Check the split (--splits / --min-silence / --align).`);
        }
      });
    }

    const lineById = new Map(lines.map((l) => [l.id, l]));
    const rows = results.map((r) => [r.id, rel(r.src).startsWith('out/') ? `full.* @${round(r.segOffset, 2)} s` : rel(r.src), `${round(r.cutStart, 2)}-${round(r.cutEnd, 2)}`, round(r.cutEnd - r.cutStart, 2)]);
    if (dry) {
      console.log(table(['line', 'source', 'cut s', 'length s'], rows));
      if (client) {
        // per-line word timings: one forced-alignment call per line that is not cached yet
        const tts = (id) => lines.find((l) => l.id === id).tts_text;
        const todo = fullAlignPlanned ? [] : results.filter((r) => !r.words && !faCached(faKey(r.srcFile, r.cut, tts(r.id))));
        if (fullAlignPlanned) {
          console.log('\n--align: if that alignment does not match the script, the real run aligns each line on its own instead (one call per line).');
        } else if (todo.length) {
          const secs = todo.reduce((n, r) => n + (r.cutEnd - r.cutStart), 0);
          console.log(`\n--align: the real run calls POST ${cfg.baseUrl}/v1/forced-alignment for ${todo.map((r) => r.id).join(', ')}`);
          console.log(`  (${todo.length} call(s), about ${round(secs, 1)} s of audio, billed like speech-to-text). Nothing was sent now.`);
        } else console.log('\n--align: word timings for every line are in the cache (no request, nothing billed).');
      }
      console.log('\ndry run: nothing written.');
      return;
    }

    mkdirSync(VO_DIR, { recursive: true });
    const entries = [];
    for (const r of results) {
      const l = lineById.get(r.id);
      const out = join(VO_DIR, `${r.id}.wav`);
      for (const ext of ['mp3', 'm4a']) rmSync(join(VO_DIR, `${r.id}.${ext}`), { force: true });
      rmSync(join(VO_DIR, `${r.id}.alignment.json`), { force: true });
      await toWav(r.src, out, { start: r.cutStart, end: r.cutEnd, rate: 48000, channels: 1 });
      let words = r.words || [];
      if (client && !r.words) {
        try {
          const key = faKey(r.srcFile, r.cut, l.tts_text);
          const fa = await align(key, { audio: readFileSync(out), filename: `${r.id}.wav`, mime: 'audio/wav', text: l.tts_text, seconds: r.cutEnd - r.cutStart });
          words = wordsFromForcedAlignment(fa);
        } catch (e) {
          if (!(e instanceof ApiError)) throw e;
          warnApi(`${r.id}: forced alignment`, e);
          if (['auth', 'quota', 'permission', 'paid_plan', 'forbidden'].includes(e.kind)) {
            console.log('  no further forced-alignment calls in this run; the lines are timed from the waveform alone.');
            client = null;
          } else console.log(`  ${r.id} gets no word timings (captions split by characters).`);
        }
      }
      if (words.length) writeJson(join(VO_DIR, `${r.id}.alignment.json`), { id: r.id, text: l.tts_text, source: 'forced-alignment', words });
      const m = await measureSpeech(out, { words, noiseDb });
      entries.push({
        id: r.id,
        source: 'import',
        text: l.text,
        tts_text: l.tts_text,
        file: publicSrc(out),
        ...m,
        words,
        alignment_source: words.length ? 'forced-alignment' : 'none',
        imported_from: mode === 'full' ? `${rel(fullFile)} ${round(r.segOffset + r.cutStart, 3)}-${round(r.segOffset + r.cutEnd, 3)} s` : rel(r.src),
        request_id: null,
      });
      r.m = m;
    }
    const old = loadManifest();
    const keep = old && mode === 'lines' ? old.lines.filter((e) => !entries.some((n) => n.id === e.id) && entryFileExists(e)) : [];
    saveManifest({ version: 1, source: 'import', voice_id: null, model_id: null, output_format: 'wav_48000_mono', lines: [...keep, ...entries] }, ids);
    console.log(
      table(
        ['line', 'source', 'cut s', 'length s', 'speech s', 'words'],
        results.map((r, i) => [...rows[i], `${r.m.speech_start_s}-${r.m.speech_end_s}`, entries[i].words.length || '']),
      ),
    );
    const have = new Set([...keep, ...entries].map((e) => e.id));
    const still = ids.filter((id) => !have.has(id));
    console.log(`\nwrote ${entries.length} file(s) to ${rel(VO_DIR)}/ and ${rel(MANIFEST)}${still.length ? `; still missing: ${still.join(', ')}` : ''}.`);
    if (args.align) {
      console.log(
        faBilled.calls
          ? `forced alignment: ${faBilled.calls} call(s) on about ${round(faBilled.seconds, 1)} s of audio (billed like speech-to-text); cached for re-runs.`
          : 'forced alignment: nothing billed (cache, or no call).',
      );
    }
    console.log('next: npm run vo:fit');
  } finally {
    rmSync(tmpDir, { recursive: true, force: true });
  }
});
