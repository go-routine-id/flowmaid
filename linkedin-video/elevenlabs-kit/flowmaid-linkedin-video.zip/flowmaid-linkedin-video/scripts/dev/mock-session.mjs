// Test the audio pipeline against the local mock API (scripts/dev/mock-elevenlabs.mjs) and put the
// project back EXACTLY as it was afterwards.
//   npm run mock:on      save the project state to .cache/mock-session/ and write .env.local that points
//                        every ElevenLabs script at the mock (http://127.0.0.1:8787, key "mock-key")
//   npm run mock:off     restore the saved state, delete what the test made, delete that .env.local
//   npm run mock:status  is a mock session active?
// Saved and restored: voiceover/lines.json, public/audio/mix.json, public/audio/sfx/plan.json,
// src/flowmaid/timeline.ts, src/flowmaid/audio/audio.generated.ts, out/audio-fit.json, out/cues.*,
// out/captions.srt, and everything under public/audio/vo/, public/audio/sfx/library/, public/audio/music/.
// Deleted by mock:off: files the test added there, new files in out/ and new .cache/elevenlabs/ entries.
// So offsets, speed overrides or wording tried on the mock's fake tones never reach the real run.
// The mock server itself is a separate process: start it with npm run mock:elevenlabs, stop it yourself.
import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, rmdirSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, sep } from 'node:path';
import { CACHE, GENERATED_TS, LINES_JSON, MIX_JSON, MUSIC_DIR, OUT, ROOT, SFX_LIBRARY, SFX_PLAN, VO_DIR, rel } from '../lib/paths.mjs';
import { parseArgs, readJson, runMain, UserError, writeJson } from '../lib/util.mjs';

const USAGE = `
usage: node scripts/dev/mock-session.mjs on|off|status [--port 8787]
  on      save the project state, write .env.local for the mock (refuses if .env.local exists)
  off     restore the saved state and delete what the mock test made (and that .env.local)
  status  say whether a mock session is active
`;

const SNAP = join(ROOT, '.cache', 'mock-session');
const META = join(SNAP, 'session.json');
const ENV_LOCAL = join(ROOT, '.env.local');
const MARKER = '# written by npm run mock:on (local mock test); npm run mock:off deletes this file';
const FILES = [LINES_JSON, MIX_JSON, SFX_PLAN, join(ROOT, 'src', 'flowmaid', 'timeline.ts'), GENERATED_TS,
  join(OUT, 'audio-fit.json'), join(OUT, 'cues.csv'), join(OUT, 'cues.md'), join(OUT, 'captions.srt')];
const DIRS = [VO_DIR, SFX_LIBRARY, MUSIC_DIR];
const toKey = (abs) => relative(ROOT, abs).split(sep).join('/');
const fromKey = (key) => join(ROOT, ...key.split('/'));

/** every file below dir (relative keys), [] if dir is missing */
const walk = (dir) => {
  if (!existsSync(dir)) return [];
  const out = [];
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) out.push(...walk(p));
    else out.push(toKey(p));
  }
  return out;
};
/** top-level entries of a dir (files and folders), [] if missing */
const top = (dir) => (existsSync(dir) ? readdirSync(dir) : []);
const copyInto = (from, to) => {
  mkdirSync(dirname(to), { recursive: true });
  copyFileSync(from, to);
};
/** remove empty folders below dir that were not there when the session started */
const pruneDirs = (dir, keepDirs) => {
  if (!existsSync(dir) || !statSync(dir).isDirectory()) return;
  for (const name of readdirSync(dir)) pruneDirs(join(dir, name), keepDirs);
  if (!keepDirs.has(toKey(dir)) && readdirSync(dir).length === 0) rmdirSync(dir);
};
const dirsOf = (keys) => {
  const s = new Set();
  for (const k of keys) {
    const parts = k.split('/');
    for (let i = 1; i < parts.length; i++) s.add(parts.slice(0, i).join('/'));
  }
  return s;
};

const on = (port) => {
  if (existsSync(META)) throw new UserError('a mock session is already active (npm run mock:off ends it).');
  for (const k of ['ELEVENLABS_API_KEY', 'ELEVENLABS_BASE_URL']) {
    if (process.env[k] !== undefined && process.env[k].trim() !== '') {
      throw new UserError(`${k} is set in this shell; it would win over .env.local and the scripts would not use the mock.`, [
        'Open a new terminal without it (or unset it) and run npm run mock:on again. The value is not printed.',
      ]);
    }
  }
  if (existsSync(ENV_LOCAL)) {
    throw new UserError('.env.local already exists, and mock:on needs that file for the mock settings.', [
      'Rename it while testing (for example to .env.local.off) and rename it back after npm run mock:off.',
      'Do not open or print it: it may hold a key.',
    ]);
  }
  mkdirSync(SNAP, { recursive: true });
  const files = [];
  for (const f of FILES) {
    if (!existsSync(f)) continue;
    copyInto(f, join(SNAP, 'files', ...toKey(f).split('/')));
    files.push(toKey(f));
  }
  const dirFiles = DIRS.flatMap(walk);
  for (const k of dirFiles) copyInto(fromKey(k), join(SNAP, 'files', ...k.split('/')));
  const meta = {
    version: 1,
    files,
    dirs: DIRS.map(toKey),
    dirFiles,
    dirDirs: [...dirsOf(dirFiles), ...DIRS.filter((d) => existsSync(d)).map(toKey)],
    out: top(OUT),
    cache: walk(CACHE),
    envLocal: true,
  };
  writeFileSync(
    ENV_LOCAL,
    `${MARKER}\nELEVENLABS_BASE_URL=http://127.0.0.1:${port}\nELEVENLABS_API_KEY=mock-key\n`,
  );
  writeJson(META, meta);
  console.log(`mock session on: saved ${files.length + dirFiles.length} file(s) to ${rel(SNAP)}/, wrote .env.local (mock at http://127.0.0.1:${port}).`);
  console.log('next: start the mock in the background (npm run mock:elevenlabs), run any playbook, then stop the mock and run npm run mock:off.');
};

const off = () => {
  if (!existsSync(META)) throw new UserError('no mock session is active (npm run mock:on was not run, or mock:off already ran).');
  const meta = readJson(META);
  const saved = new Set([...meta.files, ...meta.dirFiles]);
  let restored = 0;
  let removed = 0;
  // 1. tracked single files: back to the saved copy, or gone if they did not exist
  for (const f of FILES) {
    const k = toKey(f);
    if (meta.files.includes(k)) {
      copyInto(join(SNAP, 'files', ...k.split('/')), f);
      restored++;
    } else if (existsSync(f)) {
      rmSync(f, { force: true });
      removed++;
    }
  }
  // 2. audio folders: drop new files, put every saved file back
  for (const d of meta.dirs) {
    for (const k of walk(fromKey(d))) {
      if (!saved.has(k)) {
        rmSync(fromKey(k), { force: true });
        removed++;
      }
    }
  }
  for (const k of meta.dirFiles) {
    copyInto(join(SNAP, 'files', ...k.split('/')), fromKey(k));
    restored++;
  }
  const keepDirs = new Set(meta.dirDirs);
  for (const d of meta.dirs) pruneDirs(fromKey(d), keepDirs);
  // 3. renders and stills made during the test (new top-level entries in out/)
  const outBefore = new Set(meta.out);
  for (const name of top(OUT)) {
    if (outBefore.has(name) || meta.files.includes(`out/${name}`)) continue;
    rmSync(join(OUT, name), { recursive: true, force: true });
    removed++;
  }
  // 4. mock responses in the API cache (never reused for real requests, but they take space)
  const cacheBefore = new Set(meta.cache);
  for (const k of walk(CACHE)) {
    if (!cacheBefore.has(k)) {
      rmSync(fromKey(k), { force: true });
      removed++;
    }
  }
  pruneDirs(CACHE, dirsOf(meta.cache));
  // 5. the .env.local that mock:on wrote (only if it is still ours)
  if (existsSync(ENV_LOCAL)) {
    const first = readFileSync(ENV_LOCAL, 'utf8').split(/\r?\n/)[0];
    if (first === MARKER) rmSync(ENV_LOCAL, { force: true });
    else console.log('warning: .env.local was replaced during the test, so it was not deleted. Remove the mock lines from it yourself.');
  }
  rmSync(SNAP, { recursive: true, force: true });
  const dotCache = join(ROOT, '.cache');
  if (existsSync(dotCache) && readdirSync(dotCache).length === 0) rmdirSync(dotCache);
  console.log(`mock session off: restored ${restored} file(s), removed ${removed} file(s) made during the test, deleted .env.local.`);
  console.log('Stop the mock server process if it still runs. The project is as it was before npm run mock:on.');
};

runMain(async () => {
  const args = parseArgs(process.argv.slice(2), { port: 'number' }, USAGE);
  const cmd = args._[0];
  if (cmd === 'on') return on(args.port ?? 8787);
  if (cmd === 'off') return off();
  if (cmd === 'status') {
    console.log(existsSync(META) ? `mock session active (saved state in ${rel(SNAP)}/; end it with npm run mock:off)` : 'no mock session active');
    return;
  }
  throw new UserError('say on, off or status', USAGE.trim().split('\n'));
});
