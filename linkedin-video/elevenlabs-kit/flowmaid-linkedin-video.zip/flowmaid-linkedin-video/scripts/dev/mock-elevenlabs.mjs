// Local mock of the ElevenLabs endpoints these scripts call, for testing without a key or credits.
//   npm run mock:elevenlabs                      -> http://127.0.0.1:8787
//   node scripts/dev/mock-elevenlabs.mjs --port 0 --fail 429:2
// Point the scripts at it with  npm run mock:on  (writes .env.local: ELEVENLABS_BASE_URL=http://127.0.0.1:8787,
// ELEVENLABS_API_KEY=mock-key) and undo everything with  npm run mock:off  (CLAUDE.md, Playbook G).
// Any non-empty key works; the keys "bad" or "invalid" get 401 invalid_api_key.
//
// Endpoints (same shapes as pkg facts §1-5, §9):
//   GET  /v1/voices, /v2/voices (voice_type, search, voice_ids, page_size, next_page_token)
//   POST /v1/text-to-speech/{voice}/with-timestamps  -> {audio_base64, alignment, normalized_alignment}
//   POST /v1/text-to-speech/{voice}                  -> audio
//   POST /v1/sound-generation                        -> audio
//   POST /v1/forced-alignment (multipart file+text)  -> {characters, words, loss}
//   GET  /v1/models, /v1/user/subscription
// Audio is real: a soft tone per word at ~14 characters per second (divided by voice_settings.speed),
// 0.12 s silence before, 0.25 s after, encoded with ffmpeg in the requested output_format.
// Voice "libraryvoice0000000000" answers 402 paid_plan_required (Free plan + Voice Library voice).
//
// Test switches:
//   --fail 401|402|403|perm|quota|429[:N]|500[:N]   fail every request (or the next N) with that error:
//      401   invalid_api_key           402  paid_plan_required (Voice Library voice on Free)
//      perm  401 missing_permissions (a key without a permission; the live API answers 401, not 403)
//      quota 401 insufficient_credits / quota_exceeded (live shape: type payment_required)
//      403   IP allowlist refusal (shape UNVERIFIED)       429 concurrent_limit_exceeded    500 internal_error
//   --fail-path REGEX                          only for matching paths
//   --no-alignment                             with-timestamps responses carry no alignment (v4-like)
//   --rate 14                                  characters per second of the fake speech
//   --tier mock --credits 10000                subscription preflight: plan tier and monthly credits
//                                              (--tier free --credits 100 tests the "not enough credits" stop)
//   POST /__mock/fail {"mode":"429","count":2,"path":"text-to-speech"}   change it at runtime
//   GET  /__mock/log   request log (never contains the key)   POST /__mock/reset  clear log + switches
import { createServer } from 'node:http';
import { rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { detectSilences, mp3FromPcm16, soundSegments, wavFromPcm16 } from '../lib/ff.mjs';
import { parseArgs, runMain } from '../lib/util.mjs';
import { sfxLike, speechLike } from './synth.mjs';

const USAGE = `
usage: node scripts/dev/mock-elevenlabs.mjs [--port 8787] [--host 127.0.0.1] [--fail MODE[:N]] [--fail-path REGEX] [--no-alignment] [--rate 14]
                                           [--tier mock] [--credits 10000]
`;

const VOICES = [
  { voice_id: 'JBFqnCBsd6RMkjVDRZzb', name: 'George', category: 'premade', labels: { gender: 'male', age: 'middle_aged', accent: 'british', use_case: 'narration' } },
  { voice_id: 'EXAVITQu4vr4xnSDxMaL', name: 'Sarah', category: 'premade', labels: { gender: 'female', age: 'young', accent: 'american', use_case: 'news' } },
  { voice_id: 'onwK4e9ZLuTAKqWW03F9', name: 'Daniel', category: 'premade', labels: { gender: 'male', age: 'middle_aged', accent: 'british', use_case: 'news' } },
  { voice_id: 'mockcloned000000000001', name: 'Mock Cloned Voice', category: 'cloned', labels: { gender: 'male' } },
  { voice_id: 'libraryvoice0000000000', name: 'Mock Library Voice', category: 'professional', labels: { gender: 'female' } },
].map((v) => ({ ...v, preview_url: `http://127.0.0.1/mock-preview/${v.voice_id}.mp3` }));

// {detail: {type, code, message, status (legacy), request_id}}; `legacy` defaults to the code
const errorBody = (status, code, message, type = status === 422 ? 'validation_error' : 'error', legacy = code) => ({
  detail: { type, code, message, status: legacy, request_id: 'mock-err' },
});
/** mode -> [http status, code, message, type, legacy status] */
const FAILS = {
  401: [401, 'invalid_api_key', 'Invalid API key', 'authentication_error'],
  402: [402, 'paid_plan_required', 'Free users cannot use library voices via the API. Please upgrade your subscription.', 'payment_required'],
  perm: [401, 'missing_permissions', 'The API key you used is missing the permission text_to_speech to execute this operation.', 'authentication_error'],
  quota: [401, 'insufficient_credits', 'You have insufficient credits to complete this request. 12 credits remaining, 47 credits required.', 'payment_required', 'quota_exceeded'],
  403: [403, 'ip_not_allowed', 'Requests from this IP address are not allowed for this API key.', 'authorization_error'],
  429: [429, 'concurrent_limit_exceeded', 'Too many concurrent requests', 'rate_limit_error'],
  500: [500, 'internal_error', 'Internal server error', 'server_error'],
};

/** minimal multipart/form-data parser: {fields: {name: string}, files: {name: {filename, data}}} */
const parseMultipart = (buf, contentType) => {
  const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
  if (!m) return null;
  const boundary = Buffer.from(`--${m[1] || m[2]}`);
  const out = { fields: {}, files: {} };
  let pos = buf.indexOf(boundary);
  while (pos >= 0) {
    const next = buf.indexOf(boundary, pos + boundary.length);
    if (next < 0) break;
    const part = buf.subarray(pos + boundary.length + 2, next - 2); // skip CRLF after boundary, CRLF before next
    const sep = part.indexOf('\r\n\r\n');
    if (sep > 0) {
      const head = part.subarray(0, sep).toString('utf8');
      const data = part.subarray(sep + 4);
      const name = /name="([^"]*)"/i.exec(head)?.[1];
      const filename = /filename="([^"]*)"/i.exec(head)?.[1];
      if (name) {
        if (filename !== undefined) out.files[name] = { filename, data };
        else out.fields[name] = data.toString('utf8');
      }
    }
    pos = next;
  }
  return out;
};

const sampleRateOf = (fmt) => Number(/_(\d+)/.exec(fmt || '')?.[1]) || 44100;

const encode = async (pcm, sampleRate, fmt) => {
  if (/^pcm_/.test(fmt)) return { bytes: pcm, type: 'audio/pcm' };
  if (/^wav_/.test(fmt)) return { bytes: wavFromPcm16(pcm, sampleRate), type: 'audio/wav' };
  const kbps = Number(/^mp3_\d+_(\d+)/.exec(fmt || '')?.[1]) || 128;
  return { bytes: await mp3FromPcm16(pcm, sampleRate, kbps), type: 'audio/mpeg' };
};

runMain(async () => {
  const args = parseArgs(
    process.argv.slice(2),
    { port: 'number', host: 'string', fail: 'string', 'fail-path': 'string', 'no-alignment': 'bool', rate: 'number', tier: 'string', credits: 'number' },
    USAGE,
  );
  const host = args.host || '127.0.0.1';
  const rate = args.rate || 14;
  const state = { log: [], used: 0, n: 0, fail: null };
  const setFail = (spec, path) => {
    if (!spec) return (state.fail = null);
    const [mode, count] = String(spec).split(':');
    if (!FAILS[mode]) throw new Error(`unknown --fail mode ${mode} (use ${Object.keys(FAILS).join(', ')})`);
    state.fail = { mode, left: count ? Number(count) : Infinity, path: path ? new RegExp(path) : null };
  };
  setFail(args.fail, args['fail-path']);

  const server = createServer(async (req, res) => {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const raw = Buffer.concat(chunks);
    const url = new URL(req.url, `http://${host}`);
    const path = url.pathname;
    const send = (status, body, headers = {}) => {
      const isBuf = Buffer.isBuffer(body);
      res.writeHead(status, { 'content-type': isBuf ? headers['content-type'] || 'application/octet-stream' : 'application/json', ...headers });
      res.end(isBuf ? body : JSON.stringify(body));
    };
    try {
      // ── control endpoints ──
      if (path === '/__mock/log') return send(200, { requests: state.log, characters_used: state.used });
      if (path === '/__mock/reset') {
        state.log = [];
        state.used = 0;
        state.fail = null;
        return send(200, { ok: true });
      }
      if (path === '/__mock/fail') {
        const b = raw.length ? JSON.parse(raw.toString('utf8')) : {};
        setFail(b.mode ? `${b.mode}${b.count ? `:${b.count}` : ''}` : null, b.path);
        return send(200, { ok: true, fail: state.fail && { mode: state.fail.mode, left: state.fail.left } });
      }

      const key = req.headers['xi-api-key'];
      const entry = { n: ++state.n, method: req.method, path, query: Object.fromEntries(url.searchParams), has_key: !!key };
      const ctype = String(req.headers['content-type'] || '');
      let json = null;
      if (ctype.includes('application/json') && raw.length) {
        json = JSON.parse(raw.toString('utf8'));
        entry.body = json;
      }
      state.log.push(entry);
      const rid = `mock-req-${String(state.n).padStart(4, '0')}`;

      if (!key) return send(401, errorBody(401, 'missing_api_key', 'Missing API key', 'authentication_error'), { 'request-id': rid });
      if (/^(bad|invalid)$/i.test(key)) return send(401, errorBody(401, 'invalid_api_key', 'Invalid API key', 'authentication_error'), { 'request-id': rid });
      if (state.fail && state.fail.left > 0 && (!state.fail.path || state.fail.path.test(path))) {
        state.fail.left--;
        const [st, code, msg, type, legacy] = FAILS[state.fail.mode];
        entry.failed = `${st} ${code}`;
        const h = { 'request-id': rid };
        if (st === 429) h['retry-after'] = '1';
        // a missing permission names the permission of the endpoint that was called
        const perm = /voices/.test(path) ? 'voices_read' : /sound-generation/.test(path) ? 'sound_generation' : /forced-alignment/.test(path) ? 'forced_alignment' : /user/.test(path) ? 'user_read' : 'text_to_speech';
        return send(st, errorBody(st, code, state.fail.mode === 'perm' ? msg.replace('text_to_speech', perm) : msg, type, legacy), h);
      }

      // ── read-only endpoints ──
      if (req.method === 'GET' && path === '/v1/voices') return send(200, { voices: VOICES });
      if (req.method === 'GET' && path === '/v2/voices') {
        let list = VOICES;
        const vt = url.searchParams.get('voice_type');
        if (vt === 'default') list = list.filter((v) => v.category === 'premade');
        else if (vt === 'personal' || vt === 'non-default') list = list.filter((v) => v.category !== 'premade');
        const s = url.searchParams.get('search');
        if (s) list = list.filter((v) => JSON.stringify(v).toLowerCase().includes(s.toLowerCase()));
        const ids = url.searchParams.getAll('voice_ids').flatMap((x) => x.split(','));
        if (ids.length) list = list.filter((v) => ids.includes(v.voice_id));
        const size = Math.min(100, Number(url.searchParams.get('page_size')) || 10);
        const start = Number(url.searchParams.get('next_page_token')) || 0;
        const page = list.slice(start, start + size);
        const more = start + size < list.length;
        return send(200, { voices: page, has_more: more, total_count: list.length, next_page_token: more ? String(start + size) : null });
      }
      if (req.method === 'GET' && path === '/v1/models') {
        return send(200, [
          { model_id: 'eleven_multilingual_v2', can_do_text_to_speech: true, can_use_style: true, can_use_speaker_boost: true, maximum_text_length_per_request: 10000 },
          { model_id: 'eleven_flash_v2_5', can_do_text_to_speech: true, can_use_style: false, can_use_speaker_boost: true, maximum_text_length_per_request: 40000 },
        ]);
      }
      if (req.method === 'GET' && path === '/v1/user/subscription') {
        const tier = args.tier || 'mock';
        return send(200, { tier, character_count: state.used, character_limit: args.credits ?? 10000, can_extend_character_limit: tier !== 'free' && tier !== 'mock' });
      }

      // ── text to speech ──
      const tts = /^\/v1\/text-to-speech\/([^/]+)(\/with-timestamps)?$/.exec(path);
      if (req.method === 'POST' && tts) {
        const voice = decodeURIComponent(tts[1]);
        const v = VOICES.find((x) => x.voice_id === voice);
        if (!v) return send(404, errorBody(404, 'voice_not_found', `A voice with the voice_id ${voice} was not found.`), { 'request-id': rid });
        if (v.category === 'professional') return send(402, errorBody(402, ...FAILS[402].slice(1)), { 'request-id': rid });
        if (!json || typeof json.text !== 'string' || !json.text.trim()) {
          return send(422, { detail: [{ loc: ['body', 'text'], msg: 'Field required', type: 'missing' }] });
        }
        const speed = json.voice_settings && Number.isFinite(json.voice_settings.speed) ? json.voice_settings.speed : 1;
        if (speed < 0.7 || speed > 1.2) return send(400, errorBody(400, 'invalid_voice_settings', 'speed must be between 0.7 and 1.2'));
        const fmt = url.searchParams.get('output_format') || 'mp3_44100_128';
        const sr = sampleRateOf(fmt);
        const s = speechLike(json.text, { sampleRate: sr, charsPerSecond: rate, speed });
        const { bytes, type } = await encode(s.pcm, sr, fmt);
        state.used += json.text.length;
        const h = { 'request-id': rid, 'x-character-count': String(json.text.length) };
        if (!tts[2]) return send(200, bytes, { ...h, 'content-type': type });
        const al = args['no-alignment'] ? null : s.alignment;
        return send(200, { audio_base64: bytes.toString('base64'), alignment: al, normalized_alignment: al }, h);
      }

      // ── sound effects ──
      if (req.method === 'POST' && path === '/v1/sound-generation') {
        if (!json || !json.text) return send(422, { detail: [{ loc: ['body', 'text'], msg: 'Field required', type: 'missing' }] });
        const d = json.duration_seconds;
        if (d !== undefined && d !== null && (d < 0.5 || d > 30)) return send(422, { detail: [{ loc: ['body', 'duration_seconds'], msg: 'must be between 0.5 and 30', type: 'value_error' }] });
        const fmt = url.searchParams.get('output_format') || 'mp3_44100_128';
        const sr = sampleRateOf(fmt);
        const s = sfxLike(json.text, { sampleRate: sr, duration: d || 1.5 });
        const { bytes, type } = await encode(s.pcm, sr, fmt);
        return send(200, bytes, { 'request-id': rid, 'content-type': type });
      }

      // ── forced alignment: spread the text over the sound stretches of the file ──
      if (req.method === 'POST' && path === '/v1/forced-alignment') {
        const mp = parseMultipart(raw, ctype);
        if (!mp || !mp.files.file || !mp.fields.text) return send(422, { detail: [{ loc: ['body', 'file'], msg: 'file and text required', type: 'missing' }] });
        entry.body = { text: mp.fields.text, file: mp.files.file.filename, bytes: mp.files.file.data.length };
        const ext = (/\.(\w+)$/.exec(mp.files.file.filename || '')?.[1] || 'mp3').toLowerCase();
        const tmp = join(tmpdir(), `mock-fa-${process.pid}-${state.n}.${ext}`);
        writeFileSync(tmp, mp.files.file.data);
        let segs;
        try {
          segs = soundSegments(await detectSilences(tmp, { noiseDb: -40, minDur: 0.15 }));
        } finally {
          rmSync(tmp, { force: true });
        }
        const text = mp.fields.text;
        const chars = Array.from(text);
        const total = segs.reduce((n, sg) => n + (sg.end - sg.start), 0);
        const at = (p) => {
          // p in [0, total] speech time -> file time
          let acc = 0;
          for (const sg of segs) {
            const len = sg.end - sg.start;
            if (p <= acc + len) return sg.start + (p - acc);
            acc += len;
          }
          return segs.length ? segs[segs.length - 1].end : 0;
        };
        const r3 = (x) => Math.round(x * 1000) / 1000;
        const characters = chars.map((c, k) => ({ text: c, start: r3(at((k / chars.length) * total)), end: r3(at(((k + 1) / chars.length) * total)) }));
        const words = [];
        let cur = null;
        characters.forEach((c) => {
          if (/\s/.test(c.text)) {
            if (cur) words.push(cur);
            cur = null;
            return;
          }
          if (!cur) cur = { text: '', start: c.start, end: c.end, loss: 0.1 };
          cur.text += c.text;
          cur.end = c.end;
        });
        if (cur) words.push(cur);
        return send(200, { characters, words, loss: 0.1 }, { 'request-id': rid });
      }

      return send(404, { detail: { code: 'not_found', message: `mock: no route ${req.method} ${path}` } });
    } catch (e) {
      send(500, { detail: { code: 'mock_error', message: String(e && e.message) } });
    }
  });
  await new Promise((r) => server.listen(args.port ?? 8787, host, r));
  const { port } = server.address();
  console.log(`mock ElevenLabs API listening on http://${host}:${port}`);
  console.log(`use: npm run mock:on (writes .env.local with ELEVENLABS_BASE_URL=http://${host}:${port}, ELEVENLABS_API_KEY=mock-key); stop with Ctrl+C, then npm run mock:off`);
  if (state.fail) console.log(`failing: ${state.fail.mode} x ${state.fail.left}${state.fail.path ? ` on ${state.fail.path}` : ''}`);
});
