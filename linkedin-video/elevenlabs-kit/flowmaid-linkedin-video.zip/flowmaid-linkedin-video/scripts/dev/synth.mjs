// Deterministic test audio for the local ElevenLabs mock (scripts/dev/mock-elevenlabs.mjs):
// a soft "speech-like" tone (one tone burst per word, silence at spaces) with a matching character
// alignment, and noise-burst sound effects. Plain JS PCM; mp3 encoding goes through ff.mjs.

/** 32-bit FNV-1a hash of a string */
export const hash32 = (s) => {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
};

/** small deterministic PRNG (mulberry32) */
export const prng = (seed) => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

const toPcm16 = (f32) => {
  const b = Buffer.alloc(f32.length * 2);
  for (let i = 0; i < f32.length; i++) b.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(f32[i] * 32767))), i * 2);
  return b;
};

/**
 * "Speech" for `text`: `charsPerSecond` characters per second (divided by speed), `lead` s of
 * silence before the first character and `tail` s after the last. Returns raw s16le mono PCM plus
 * the ElevenLabs-shaped character alignment (seconds from the clip start).
 */
export const speechLike = (text, { sampleRate = 44100, charsPerSecond = 14, speed = 1, lead = 0.12, tail = 0.25 } = {}) => {
  const dt = 1 / (charsPerSecond * (speed > 0 ? speed : 1));
  const chars = Array.from(text);
  const dur = lead + chars.length * dt + tail;
  const n = Math.ceil(dur * sampleRate);
  const f32 = new Float32Array(n);
  const starts = chars.map((_, i) => Math.round((lead + i * dt) * 1000) / 1000);
  const ends = chars.map((_, i) => Math.round((lead + (i + 1) * dt) * 1000) / 1000);
  // one tone burst per word
  let i = 0;
  while (i < chars.length) {
    if (/\s/.test(chars[i])) {
      i++;
      continue;
    }
    let j = i;
    while (j < chars.length && !/\s/.test(chars[j])) j++;
    const t0 = lead + i * dt;
    const t1 = lead + j * dt;
    const f0 = 150 + (hash32(chars.slice(i, j).join('')) % 7) * 12;
    const a = Math.floor(t0 * sampleRate);
    const b = Math.min(n, Math.floor(t1 * sampleRate));
    const att = Math.floor(0.01 * sampleRate);
    const rel = Math.floor(0.02 * sampleRate);
    for (let k = a; k < b; k++) {
      const t = k / sampleRate;
      const env = Math.min(1, (k - a) / att, (b - k) / rel);
      const vib = 1 + 0.03 * Math.sin(2 * Math.PI * 5 * t);
      const x = Math.sin(2 * Math.PI * f0 * vib * t) + 0.35 * Math.sin(4 * Math.PI * f0 * t) + 0.12 * Math.sin(6 * Math.PI * f0 * t);
      f32[k] = 0.22 * env * x;
    }
    i = j;
  }
  return {
    pcm: toPcm16(f32),
    sampleRate,
    duration: n / sampleRate,
    alignment: { characters: chars, character_start_times_seconds: starts, character_end_times_seconds: ends },
  };
};

/** a sound effect: filtered noise burst with a fast attack and exponential decay */
export const sfxLike = (prompt, { sampleRate = 44100, duration = 1.0 } = {}) => {
  const n = Math.max(1, Math.round(duration * sampleRate));
  const rnd = prng(hash32(prompt));
  const f32 = new Float32Array(n);
  const decay = 3 + (hash32(prompt) % 5);
  let lp = 0;
  for (let k = 0; k < n; k++) {
    const t = k / n;
    lp = lp * 0.6 + (rnd() * 2 - 1) * 0.4;
    const env = Math.min(1, k / (0.005 * sampleRate)) * Math.exp(-decay * t);
    f32[k] = 0.5 * env * lp;
  }
  return { pcm: toPcm16(f32), sampleRate, duration: n / sampleRate };
};
