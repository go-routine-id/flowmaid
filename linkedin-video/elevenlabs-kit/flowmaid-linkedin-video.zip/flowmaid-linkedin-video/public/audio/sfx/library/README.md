# Pustaka efek suara

Satu file per kategori, nama file = nama kategori (boleh `.mp3` atau `.wav`):
`pop`, `click`, `key`, `typing-bed`, `tick`, `thud`, `whoosh`, `swish`, `chime`, `riser`, `flash`,
`shutter`, `drag-bed`.

Dua cara mengisi:

1. File sendiri: salin ke sini dengan nama kategori, misalnya `whoosh.wav`.
   Pastikan lisensinya boleh dipakai untuk video promosi.
2. ElevenLabs: `npm run sfx:gen` (perlu API key, memakai kredit).
   Hanya membuat kategori yang belum punya file. File milikmu tidak pernah ditimpa.

`generated.json` mencatat file yang dibuat oleh `npm run sfx:gen`.
Kategori tanpa file dilewati saja, film tetap bisa dirender.
