# Efek suara

- `plan.json`: satu baris per momen visual di film (frame, shot, kejadian, saran suara, kategori,
  volume, aktif atau tidak). Dibuat oleh `npm run sfx:plan` dan boleh diedit:
  - matikan satu efek: `"enabled": false`
  - volume: `"gain"` (0 sampai 1)
  - ganti jenis: `"category"`, geser waktu: `"offset_frames"` (30 frame = 1 detik)
- `library/`: file suara per kategori (lihat README di dalamnya).

Aturan kategori dan prompt ElevenLabs ada di `scripts/audio/sfx-categories.json`.
`npm run sfx:plan` menyimpan hasil editanmu; `npm run sfx:plan -- --fresh` mulai dari aturan lagi.
Setelah mengubah apa pun: `npm run vo:fit`.
