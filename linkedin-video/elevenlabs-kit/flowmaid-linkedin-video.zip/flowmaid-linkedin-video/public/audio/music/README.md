# Musik latar (opsional)

Taruh `bed.mp3` atau `bed.wav` di sini, minimal 36 detik (tidak diulang otomatis).
Musik otomatis mengecil saat narasi berbicara.

Atur di `public/audio/mix.json`: `music.gain` (volume), `music.duck_under_vo_to` (volume saat ada narasi),
`"enabled": false` untuk mematikan. Pastikan lisensi musiknya boleh dipakai untuk video promosi.
