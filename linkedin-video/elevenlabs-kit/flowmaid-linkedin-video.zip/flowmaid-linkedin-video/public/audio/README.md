# Audio

Semua audio untuk film ada di sini. Film tetap bisu sampai `npm run vo:fit` mengisi
`src/flowmaid/audio/audio.generated.ts`.

| Folder / file | Isi |
|---|---|
| `vo/` | Voice-over per baris (`vo1` ... `vo8`) dan `manifest.json`. Dibuat oleh `npm run vo:tts` atau `npm run vo:import`. |
| `vo/import/` | Tempat file dari web app ElevenLabs (lihat README di dalamnya). |
| `sfx/plan.json` | Daftar efek suara per momen di film (`npm run sfx:plan`). Boleh diedit. |
| `sfx/library/` | Satu file per jenis efek (`pop.mp3`, `whoosh.mp3`, ...). |
| `music/` | Musik latar (opsional): `bed.mp3` atau `bed.wav`. |
| `mix.json` | Volume, jeda antar baris, geser waktu, target loudness. |

Urutan kerja:

1. `npm run vo:tts` (lewat API) atau `npm run vo:import` (file dari web app)
2. `npm run vo:fit` (menempatkan suara dan menggeser caption)
3. `npm run render:final` → hasil: `out/flowmaid-promo-audio.mp4`

File `.mp3` lain langsung di folder ini (`pop.mp3`, `whoosh-big.mp3`, ...) milik template lama.
Film flowmaid tidak memakainya.
