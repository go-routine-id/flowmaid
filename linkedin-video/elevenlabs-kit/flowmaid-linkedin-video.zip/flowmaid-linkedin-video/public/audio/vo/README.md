# Voice-over

Isi folder ini dibuat oleh skrip. Jangan diedit manual:

- `vo1.mp3` ... `vo8.mp3` (dari `npm run vo:tts`) atau `vo1.wav` ... `vo8.wav` (dari `npm run vo:import`)
- `vo1.alignment.json` ...: waktu tiap kata (dipakai untuk caption)
- `manifest.json`: daftar file, durasi, dan kapan suara mulai dan berhenti

Kata-kata diubah di `voiceover/lines.json`, bukan di sini.
Mengulang satu baris saja: `npm run vo:tts -- --only vo3`.
