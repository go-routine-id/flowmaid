# Import dari web app ElevenLabs

Pakai folder ini kalau suara dibuat di web app ElevenLabs (tanpa API key).

- Pilihan A, satu file per baris: `vo1.mp3`, `vo2.mp3`, ..., `vo8.mp3` (boleh mp3, wav, atau m4a).
- Pilihan B, satu rekaman utuh: `full.mp3` berisi 8 baris berurutan, dengan jeda 0,7 detik antar baris
  (teks dengan tag `<break time="0.7s" />` ada di `voiceover/SCRIPT.md`).

Teks yang ditempel ke web app: kolom `tts_text` di `voiceover/lines.json`
(singkatan sudah dieja, misalnya "S V G").

Lalu jalankan:

    npm run vo:import
    npm run vo:fit

Kalau rekaman utuh terpotong salah:

- jeda pendek: `npm run vo:import -- --min-silence 0.25`
- tulis titik potong sendiri (detik): `npm run vo:import -- --splits 3.4,6.1,9.8,13.9,18.2,23.6,28.7`
- dengan API key, potong berdasarkan kata: `npm run vo:import -- --align` (memakai kredit; cek dulu dengan
  `npm run vo:import -- --align --dry-run`, yang tidak mengirim apa pun)
