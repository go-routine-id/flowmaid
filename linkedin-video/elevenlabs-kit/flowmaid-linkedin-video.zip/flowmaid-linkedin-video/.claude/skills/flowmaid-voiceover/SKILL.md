---
name: flowmaid-voiceover
description: Add or redo the ElevenLabs voice-over of the flowmaid LinkedIn video (Remotion composition FlowmaidPromo) and render the final MP4 with audio. Use when the owner asks for a voice-over, narration, "suara", "VO", ElevenLabs, a different voice, captions that follow the speech, fixing a line that is too long, or the final video with sound. Covers both the ElevenLabs API path and files made in the ElevenLabs web app.
---

# flowmaid voice-over

Read `CLAUDE.md` first (hard rules, file map, facts). Reply to the owner in short plain Indonesian.
Never print or ask for the API key in chat. Ask before any step that spends credits; show the `--dry-run` first.

## 0. Check the project

1. `npm ci` if `node_modules/` is missing. Then `npm run typecheck`.
2. `npm run vo:fit -- --dry-run` tells you the current state (no VO yet = clear message, nothing written).
3. Decide the path with the owner: API key (step 1A) or web-app files (step 1B). No key and no files? Offer the
   web-app path and point them to `voiceover/SCRIPT.md`.

## 1A. API path

1. `.env` exists? If not, copy `.env.example` to `.env` and ask the owner to paste `ELEVENLABS_API_KEY` there.
   Optional settings in `.env`: `ELEVENLABS_VOICE_ID`, `ELEVENLABS_MODEL_ID` (default `eleven_multilingual_v2`).
2. `npm run vo:voices -- --type default` (free). Show the owner 3-5 fitting voices (calm, clear, English).
3. Audition each candidate on vo1 only: set `ELEVENLABS_VOICE_ID` in `.env`, then
   `npm run vo:tts -- --only vo1 --dry-run` -> OK -> `npm run vo:tts -- --only vo1`.
   The owner listens to `public/audio/vo/vo1.mp3`. About 47 credits per voice; going back to a voice is free (cache).
   A 401 error is not always a bad key: read the advice lines (missing permission -> add it to the same key;
   insufficient credits -> stop).
4. With the chosen voice: `npm run vo:tts -- --dry-run` (about 413 credits) -> OK -> `npm run vo:tts`.
5. A line sounds wrong (pronunciation, tone): fix `tts_text` or `override` in `voiceover/lines.json`, then
   `npm run vo:tts -- --only <id>`. Spell abbreviations ("S V G", "mermaid J S", "flow C L I", "D B X", "E R D").

## 1B. Web-app path

1. The owner exports per-line files `vo1.mp3` ... `vo8.mp3` (or one `full.mp3`) into `public/audio/vo/import/`,
   made from the text in `voiceover/SCRIPT.md` with the model Eleven Multilingual v2.
2. `npm run vo:import -- --dry-run`, check the detected cuts, then `npm run vo:import`.
3. Wrong cuts in a full take: `-- --min-silence 0.25`, `-- --splits <s,s,...>`, or `-- --align` (needs a key;
   billed like speech-to-text). `npm run vo:import -- --align --dry-run` sends nothing and says what the real run
   would bill: show it, get OK, then run without `--dry-run`. Results are cached, so a re-run is free.

## 2. Fit

1. `npm run vo:fit`.
2. If it reports CLASH or TOO LONG, apply fixes in this order and re-run after each:
   - the printed offsets into `public/audio/mix.json` `vo.per_line.<id>.offset_frames` (free);
   - or `fit.auto_shift` `{ "max_early_frames": 10, "max_late_frames": 15 }`;
   - API voice: `"override": { "speed": 1.1 }` (0.7-1.2; not sent on eleven_v4) on that line, then
     `npm run vo:tts -- --only <id>`; imported file: `playback_rate` 0.9-1.15 in `vo.per_line.<id>`;
   - shorter wording only with the owner's OK, inside the claims in `BRIEF.md`. Change both files: vo1-vo7 =
     `text` + `tts_text` in `lines.json` and `text` in `VO_LINES` (`src/flowmaid/timeline.ts`); vo8 = `text`,
     `tts_text`, `captions[].text` in `lines.json` and `parts[].text` of line 8 in `VO_LINES` (CLAUDE.md, Playbook E);
   - last resort: `lead` of that line in `VO_LINES`. Never `SHOTS`.
3. Read the warnings it prints (text mismatches name both fields, clamped values) and resolve them.

## 3. Check

1. `npm run typecheck`.
2. `npm run dev` -> `FlowmaidPromo`: the owner plays it with sound. Captions must appear with their words.
3. Stills where captions changed, e.g. `npm run still:flowmaid -- out/check-f0100.png --frame=100`; look at them.

## 4. Render

1. `npm run render:final` (= `vo:fit` + `render:audio` + `audio:loudnorm`). Takes a few minutes.
2. Verify: `npx remotion ffprobe out/flowmaid-promo-audio.mp4` shows h264 + aac; the script printed about -16 LUFS.
3. Deliver: `out/flowmaid-promo-audio.mp4`, `out/captions.srt` (LinkedIn captions), `deliverables/silent/cover.png`.
4. Remind the owner: on the ElevenLabs Free plan the audio is non-commercial and the post title must contain
   "elevenlabs.io" or "11.ai"; a paid plan includes a commercial licence.

## Undo

`npm run vo:reset` makes the film silent again with the original caption windows (same as `deliverables/silent/`).
The audio files stay in `public/audio/vo/`; the next `npm run vo:fit` uses them again.
