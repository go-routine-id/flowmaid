---
name: flowmaid-sfx
description: Add, change or remove sound effects and the background music bed of the flowmaid LinkedIn video (Remotion composition FlowmaidPromo), from the owner's own files or the ElevenLabs sound-generation API. Use when the owner asks for sound effects, SFX, "efek suara", whooshes, pops, clicks, music, "musik latar", or wants the mix louder, quieter or cleaner.
---

# flowmaid sound effects and music

Read `CLAUDE.md` first. Reply in short plain Indonesian. Ask before spending credits (`--dry-run` first).

## How it works

- `public/audio/sfx/plan.json`: one entry per visual cue of the film (frame, shot, event, suggested sound,
  `category`, `enabled`, `gain`, `offset_frames`, `duration_frames`, optional `file`). 78 cues, 58 enabled.
- `public/audio/sfx/library/<category>.(wav|mp3)`: one sound per category. Categories: pop, click, key,
  typing-bed, tick, thud, whoosh, swish, chime, riser, flash, shutter, drag-bed (prompts and rules in
  `scripts/audio/sfx-categories.json`). A category without a file is skipped; the film still renders.
- `npm run vo:fit` turns enabled entries with a file into `SFX_CLIPS` and the music file into `MUSIC`.

## Steps

1. Pick the source with the owner:
   - Own files: copy them into `public/audio/sfx/library/` named by category (for example `whoosh.wav`).
     The owner confirms the licence allows a promo video. Never use the template's `public/audio/*.mp3`.
   - ElevenLabs: `npm run sfx:gen -- --dry-run` (shows requests and a credit range: about 210-430 credits for the
     categories the plan uses, since each has a fixed duration billed per second), OK, then `npm run sfx:gen`.
     Only missing categories used by enabled entries are made; the owner's files are never overwritten
     (`library/generated.json` lists what the script made). `-- --only pop,whoosh`, `-- --all`, `-- --force`
     (re-bills). 401 `missing_permissions` = the key lacks "Sound Effects": add it to the same key, or use own
     files. 402/403 = not on this plan or not from this IP: use own files.
2. Shape the plan: edit `plan.json` (`"enabled": false` to mute a hit, `gain` 0..1, `category`, `offset_frames`
   + = later, 30 f = 1 s). `npm run sfx:plan` regenerates from the cue sheet and keeps hand edits;
   `npm run sfx:plan -- --fresh` drops them.
3. Overall level: `public/audio/mix.json` `sfx.master_gain` (0.8) and `sfx.under_vo_gain` (0.55, applied while
   someone speaks). `"enabled": false` in `sfx` mutes all effects.
4. Music (optional): the owner supplies `public/audio/music/bed.mp3` or `bed.wav`, at least 36 s, licensed for
   promo use. `mix.json` `music.gain` (0.22), `music.duck_under_vo_to` (0.08, an absolute gain, not a multiplier),
   fades 15 / 45 f. No script generates music (ElevenLabs Music needs a paid plan).
5. `npm run vo:fit` (add `-- --allow-missing` while there is no voice-over yet).
6. Preview in `npm run dev` -> `FlowmaidPromo` with sound. The voice must stay clearly on top.
7. `npm run render:final` -> `out/flowmaid-promo-audio.mp4`.

## Remove everything again

Set `sfx.enabled` and `music.enabled` to false in `mix.json` and run `npm run vo:fit`, or `npm run vo:reset` for
the fully silent film.
