# Third-party notices

This folder is the Remotion project for the flowmaid LinkedIn promo. Parts of it come from other projects.

## video-shotcraft (Apache-2.0)

- Source: https://github.com/Vincentwei1021/video-shotcraft (the `template/` folder and parts of `assets/lib/`,
  `demos/_fixtures/`). Licence text: [`licenses/video-shotcraft-LICENSE`](licenses/video-shotcraft-LICENSE).
- What came from it: the project scaffold (`remotion.config.ts`, `tsconfig.json`, `package.json` base), the
  `AiflPromo` template composition (`src/aifl/`, `src/themes/`, `src/workbench.ts`, `themes/`,
  `scripts/build-palette-assets.cjs`, `public/textures/`, `TEMPLATE.md`, `THEMES.md`), and adapted copies in
  `src/flowmaid/lib/` (Caption, ClipCard, Polish, DigitRoll, ...; each file names its origin).
- Files taken from video-shotcraft were modified for this project. Everything else in `src/flowmaid/` and
  `scripts/` was written for this project.
- The template's own sound files (`public/audio/*.mp3`, listed in `public/audio/ATTRIBUTION.md`) are NOT covered
  by Apache-2.0 and some have unverified sources. Only the `AiflPromo` template uses them. Do not use them in the
  flowmaid film.

## Remotion

- Installed from npm (`remotion`, `@remotion/cli`, version 4.0.484); not bundled in this folder.
- Licence: https://github.com/remotion-dev/remotion/blob/main/LICENSE.md. The free licence covers individuals,
  for-profit organisations with up to 3 employees, non-profits, and evaluation. Larger companies need a
  Company License: https://www.remotion.dev/docs/license/pricing.
- Remotion downloads its own Chrome Headless Shell and ships its own ffmpeg/ffprobe binaries (npm packages
  `@remotion/compositor-*`), each under their own licences.

## Fonts (SIL Open Font License 1.1)

`public/fonts/`: Archivo (800, 900), Inter (400, 500, 600), JetBrains Mono (400, 500, 600). The same families are on
Google Fonts; here they are loaded from local files. Copyright lines and licence text:
[`licenses/OFL-1.1.txt`](licenses/OFL-1.1.txt).

## Other npm packages

React, React DOM (MIT), TypeScript (Apache-2.0), esbuild (MIT, installed with Remotion) and their dependencies are
installed by `npm ci` from `package-lock.json`; see each package in `node_modules/` for its licence.

## ElevenLabs

Audio you generate with ElevenLabs (API, web app or MCP) is subject to your ElevenLabs plan and terms. On the Free
plan the output may not be used commercially and must be credited ("elevenlabs.io" or "11.ai" in the title of the
post). Paid plans include a commercial licence. Details and sources: `docs/elevenlabs-api-notes.md`, section 8.

## flowmaid media

`public/clips/`, `public/frames/`, `public/svg/`, `public/hero.mmd`: screen recordings and renders of the flowmaid
project's own tools (flowmaid-web, flowcli, dbx) with demo data. flowmaid itself is GPL-3.0-or-later
(https://github.com/go-routine-id/flowmaid).
